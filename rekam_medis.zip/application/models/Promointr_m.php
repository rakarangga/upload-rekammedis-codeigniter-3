<?php
class Promointr_m extends MY_Model {
	protected $_table_nama = 'tblpromointr';
	protected $_timestamp = FALSE;
	protected $_primary_key = 'idpromointr';
	protected $_order_by = 'idpromointr';
	protected $_timepost = '';
	protected $_timeedit='';
	
	
	
	
}
