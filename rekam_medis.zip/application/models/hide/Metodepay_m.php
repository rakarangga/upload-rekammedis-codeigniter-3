<?php
class Metodepay_m extends MY_Model {
	protected $_table_nama = 'tblmetode_pay';
	protected $_timestamp = FALSE;
	protected $_primary_key = 'idmp';
	protected $_order_by = 'idmp';
	protected $_timepost = '';
	protected $_timeedit='';
	
}
