<?php
class Rulepickup_m extends MY_Model {
	protected $_table_nama = 'tbl_rules_pickup';
	protected $_timestamp = FALSE;
	protected $_primary_key = 'idrules';
	protected $_order_by = 'idrules';
	protected $_timepost = '';
	protected $_timeedit='';
	
	
	
	
}
