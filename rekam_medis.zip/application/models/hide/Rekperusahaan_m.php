<?php
class Rekperusahaan_m extends MY_Model {
	protected $_table_nama = 'tblrekeningperusahaan';
	protected $_timestamp = FALSE;
	protected $_primary_key = 'idrekening';
	protected $_order_by = 'idrekening';
	protected $_timepost = '';
	protected $_timeedit='';
	
}
