<?php
class Tarifinter_m extends MY_Model {
	protected $_table_nama = 'tbltarif_intr';
	protected $_timestamp = FALSE;
	protected $_primary_key = 'idtarifintr';
	protected $_order_by = 'idtarifintr';
	protected $_timepost = '';
	protected $_timeedit='';

/* 	public function get_new() {
		$tarifinter = new stdClass ();
		$tarifinter->tarifinter_code = '';
		$tarifinter->tarifinter_name = '';
	
		return $tarifinter;
	} */
	
	public function getTarif(){
	    
	    
	}
	
}
