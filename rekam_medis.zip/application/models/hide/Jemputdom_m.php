<?php
class Jemputdom_m extends MY_Model {
	protected $_table_nama = 'tbljemput_dom';
	protected $_timestamp = FALSE;
	protected $_primary_key = 'idjemput_dom';
	protected $_order_by = 'waktuajuan';
	protected $_timepost = 'waktuajuan';
	protected $_timeedit='';
	
	
}
