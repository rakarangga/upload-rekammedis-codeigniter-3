<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-12 01:51:02 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Pasien.php 103
ERROR - 2020-03-12 01:52:00 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Pasien.php 103
ERROR - 2020-03-12 01:55:15 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Pasien.php 103
ERROR - 2020-03-12 01:56:08 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Pasien.php 103
ERROR - 2020-03-12 01:58:50 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Pasien.php 103
ERROR - 2020-03-12 02:01:09 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Pasien.php 103
ERROR - 2020-03-12 02:03:21 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-12 02:03:21 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-12 02:03:38 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-12 02:03:38 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-12 02:08:53 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-12 02:08:53 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-12 02:09:25 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-12 02:09:25 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-12 02:11:41 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-12 02:11:41 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-12 02:12:03 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-12 02:12:03 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-12 02:12:54 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-12 02:12:54 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-12 02:13:44 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-12 02:13:44 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-12 02:14:45 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-12 02:14:45 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-12 02:15:00 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-12 02:15:00 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-12 02:16:49 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-12 02:16:49 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-12 02:17:03 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-12 02:17:03 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-12 02:17:25 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-12 02:17:25 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-12 02:17:25 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-12 02:17:25 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-12 02:25:32 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-12 02:25:32 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-12 02:25:32 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-12 02:25:32 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-12 02:25:33 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-12 02:25:33 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-12 02:26:21 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-12 02:26:21 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-12 02:32:36 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-12 02:32:36 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-12 02:32:36 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-12 02:32:36 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-12 02:32:36 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-12 02:32:36 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-12 02:33:15 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-12 02:33:15 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-12 02:33:15 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-12 02:33:15 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-12 02:33:32 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-12 02:33:32 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-12 02:33:33 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-12 02:33:33 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-12 02:33:53 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-12 02:33:53 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-12 02:33:58 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-12 02:33:58 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-12 02:34:22 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-12 02:34:22 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-12 03:15:26 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\webserver@raka\htdocs\__2020\rekam_medis\application\models\Berkas_m.php 98
ERROR - 2020-03-12 08:33:10 --> Query error: Unknown column 't_berkas' in 'field list' - Invalid query: SELECT `t_berkas`
FROM `t_pasien`
WHERE `idpasien` = '90'
AND `stts` = 1
AND `id` = 90
ORDER BY `orderby` ASC, `t_pasien`.`modified` DESC
ERROR - 2020-03-12 08:34:15 --> Query error: Unknown column 't_berkas' in 'field list' - Invalid query: SELECT `t_berkas`
FROM `t_pasien`
WHERE `idpasien` = '90'
AND `stts` = 1
AND `id` = 90
ORDER BY `orderby` ASC, `t_pasien`.`modified` DESC
ERROR - 2020-03-12 08:35:06 --> Query error: Unknown column 't_berkas' in 'field list' - Invalid query: SELECT `t_berkas`
FROM `t_berkas`
WHERE `idpasien` = '90'
AND `stts` = 1
AND `id` = 90
ORDER BY `orderby` ASC, `t_berkas`.`modified` DESC
ERROR - 2020-03-12 08:40:55 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Pasien.php 24
ERROR - 2020-03-12 08:41:21 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Pasien.php 24
ERROR - 2020-03-12 09:55:35 --> Severity: error --> Exception: syntax error, unexpected ';' D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Pasien.php 26
ERROR - 2020-03-12 09:55:45 --> Severity: error --> Exception: syntax error, unexpected ';' D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Pasien.php 26
ERROR - 2020-03-12 09:55:59 --> Severity: error --> Exception: syntax error, unexpected ';' D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Pasien.php 26
ERROR - 2020-03-12 10:59:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
AND `iddirectory` = '1'
AND `stts` = 1
ORDER BY `t_pasien`.`modified` DESC
 LI' at line 3 - Invalid query: SELECT *
FROM `t_pasien`
WHERE `id` NOT IN()
AND `iddirectory` = '1'
AND `stts` = 1
ORDER BY `t_pasien`.`modified` DESC
 LIMIT 10
ERROR - 2020-03-12 10:59:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
ORDER BY `t_pasien`.`modified` DESC' at line 3 - Invalid query: SELECT *
FROM `t_pasien`
WHERE `stts` = 1 AND  `id` NOT IN ()
ORDER BY `t_pasien`.`modified` DESC
ERROR - 2020-03-12 11:00:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
ORDER BY `t_pasien`.`modified` DESC' at line 3 - Invalid query: SELECT *
FROM `t_pasien`
WHERE `stts` = 1 AND  `id` NOT IN ()
ORDER BY `t_pasien`.`modified` DESC
ERROR - 2020-03-12 11:00:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
AND `iddirectory` = '1'
AND `stts` = 1
ORDER BY `t_pasien`.`modified` DESC
 LI' at line 3 - Invalid query: SELECT *
FROM `t_pasien`
WHERE `id` NOT IN()
AND `iddirectory` = '1'
AND `stts` = 1
ORDER BY `t_pasien`.`modified` DESC
 LIMIT 10
ERROR - 2020-03-12 11:00:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
ORDER BY `t_pasien`.`modified` DESC' at line 3 - Invalid query: SELECT *
FROM `t_pasien`
WHERE `stts` = 1 AND  `id` NOT IN ()
ORDER BY `t_pasien`.`modified` DESC
ERROR - 2020-03-12 11:01:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
AND `iddirectory` = '1'
AND `stts` = 1
ORDER BY `t_pasien`.`modified` DESC
 LI' at line 3 - Invalid query: SELECT *
FROM `t_pasien`
WHERE `id` NOT IN()
AND `iddirectory` = '1'
AND `stts` = 1
ORDER BY `t_pasien`.`modified` DESC
 LIMIT 10
ERROR - 2020-03-12 11:01:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
ORDER BY `t_pasien`.`modified` DESC' at line 3 - Invalid query: SELECT *
FROM `t_pasien`
WHERE `stts` = 1 AND  `id` NOT IN ()
ORDER BY `t_pasien`.`modified` DESC
ERROR - 2020-03-12 11:01:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
ORDER BY `t_pasien`.`modified` DESC' at line 3 - Invalid query: SELECT *
FROM `t_pasien`
WHERE `stts` = 1 AND  `id` NOT IN ()
ORDER BY `t_pasien`.`modified` DESC
ERROR - 2020-03-12 11:03:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
AND `iddirectory` = '2'
AND `stts` = 1
ORDER BY `t_pasien`.`modified` DESC
 LI' at line 3 - Invalid query: SELECT *
FROM `t_pasien`
WHERE `id` NOT IN()
AND `iddirectory` = '2'
AND `stts` = 1
ORDER BY `t_pasien`.`modified` DESC
 LIMIT 10
ERROR - 2020-03-12 11:03:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
ORDER BY `t_pasien`.`modified` DESC' at line 3 - Invalid query: SELECT *
FROM `t_pasien`
WHERE `stts` = 1 AND  `id` NOT IN ()
ORDER BY `t_pasien`.`modified` DESC
ERROR - 2020-03-12 11:12:29 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `t_berkas`
WHERE 0 = `Array`
ERROR - 2020-03-12 11:56:51 --> Severity: error --> Exception: Call to undefined method Pasien_m::get_where() D:\webserver@raka\htdocs\__2020\rekam_medis\application\models\Direktori_m.php 223
ERROR - 2020-03-12 11:57:59 --> Severity: error --> Exception: Call to undefined method Pasien_m::get_where() D:\webserver@raka\htdocs\__2020\rekam_medis\application\models\Direktori_m.php 223
