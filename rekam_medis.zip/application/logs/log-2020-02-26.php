<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-26 01:12:23 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\webserver@raka\htdocs\rekam_medis\application\views\backoffice\berkas\list_berkas.php 92
ERROR - 2020-02-26 07:53:47 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'u397728942_gr34t'@'localhost' (using password: YES) D:\webserver@raka\htdocs\2020\rekam_medis\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2020-02-26 07:53:47 --> Unable to connect to the database
ERROR - 2020-02-26 07:53:47 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'u397728942_gr34t'@'localhost' (using password: YES) D:\webserver@raka\htdocs\2020\rekam_medis\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2020-02-26 07:53:48 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) D:\webserver@raka\htdocs\2020\rekam_medis\system\libraries\Session\Session.php 140
ERROR - 2020-02-26 18:12:04 --> Severity: error --> Exception: Unable to locate the model you have specified: Voucherintr_m D:\webserver@raka\htdocs\2020\rekam_medis\system\core\Loader.php 344
