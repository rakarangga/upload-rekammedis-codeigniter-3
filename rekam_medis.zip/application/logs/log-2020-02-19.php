<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-19 04:02:52 --> Unable to connect to the database
ERROR - 2020-02-19 04:03:03 --> Unable to connect to the database
ERROR - 2020-02-19 04:20:01 --> Query error: Table 'rekam_medis.tblxxpropinsi' doesn't exist - Invalid query: SELECT `tblxxpropinsi`.`namaxxpropinsi` as `namaPropinsi`, `tblxxkotkab`.`namaxxkotkab` as `namaKotkab`, `tblxxkecamatan`.`namaxxkecamatan` as `namaKec`, `tblxxkelurahan`.`namaxxkelurahan` as `namaKel`
FROM `tblxxpropinsi`
LEFT JOIN `tblxxkotkab` ON `tblxxpropinsi`.`kodexxpropinsi` = `tblxxkotkab`.`kodexxpropinsi`
LEFT JOIN `tblxxkecamatan` ON `tblxxkotkab`.`kodexxkotkab` = `tblxxkecamatan`.`kodexxkotkab`
LEFT JOIN `tblxxkelurahan` ON `tblxxkecamatan`.`kodexxkecamatan` = `tblxxkelurahan`.`kodexxkecamatan`
WHERE 1 = 1
AND  `tblxxkotkab`.`namaxxkotkab` LIKE '%%' ESCAPE '!'
 LIMIT 30
ERROR - 2020-02-19 06:06:59 --> Query error: Table 'rekam_medis.tblxxpropinsi' doesn't exist - Invalid query: SELECT `tblxxpropinsi`.`namaxxpropinsi` as `namaPropinsi`, `tblxxkotkab`.`namaxxkotkab` as `namaKotkab`, `tblxxkecamatan`.`namaxxkecamatan` as `namaKec`, `tblxxkelurahan`.`namaxxkelurahan` as `namaKel`
FROM `tblxxpropinsi`
LEFT JOIN `tblxxkotkab` ON `tblxxpropinsi`.`kodexxpropinsi` = `tblxxkotkab`.`kodexxpropinsi`
LEFT JOIN `tblxxkecamatan` ON `tblxxkotkab`.`kodexxkotkab` = `tblxxkecamatan`.`kodexxkotkab`
LEFT JOIN `tblxxkelurahan` ON `tblxxkecamatan`.`kodexxkecamatan` = `tblxxkelurahan`.`kodexxkecamatan`
WHERE 1 = 1
AND  `tblxxkotkab`.`namaxxkotkab` LIKE '%%' ESCAPE '!'
 LIMIT 30
ERROR - 2020-02-19 06:07:01 --> Query error: Table 'rekam_medis.tblxxpropinsi' doesn't exist - Invalid query: SELECT `tblxxpropinsi`.`namaxxpropinsi` as `namaPropinsi`, `tblxxkotkab`.`namaxxkotkab` as `namaKotkab`, `tblxxkecamatan`.`namaxxkecamatan` as `namaKec`, `tblxxkelurahan`.`namaxxkelurahan` as `namaKel`
FROM `tblxxpropinsi`
LEFT JOIN `tblxxkotkab` ON `tblxxpropinsi`.`kodexxpropinsi` = `tblxxkotkab`.`kodexxpropinsi`
LEFT JOIN `tblxxkecamatan` ON `tblxxkotkab`.`kodexxkotkab` = `tblxxkecamatan`.`kodexxkotkab`
LEFT JOIN `tblxxkelurahan` ON `tblxxkecamatan`.`kodexxkecamatan` = `tblxxkelurahan`.`kodexxkecamatan`
WHERE 1 = 1
AND  `tblxxkotkab`.`namaxxkotkab` LIKE '%%' ESCAPE '!'
 LIMIT 30
ERROR - 2020-02-19 06:07:05 --> Query error: Table 'rekam_medis.tblxxpropinsi' doesn't exist - Invalid query: SELECT `tblxxpropinsi`.`namaxxpropinsi` as `namaPropinsi`, `tblxxkotkab`.`namaxxkotkab` as `namaKotkab`, `tblxxkecamatan`.`namaxxkecamatan` as `namaKec`, `tblxxkelurahan`.`namaxxkelurahan` as `namaKel`
FROM `tblxxpropinsi`
LEFT JOIN `tblxxkotkab` ON `tblxxpropinsi`.`kodexxpropinsi` = `tblxxkotkab`.`kodexxpropinsi`
LEFT JOIN `tblxxkecamatan` ON `tblxxkotkab`.`kodexxkotkab` = `tblxxkecamatan`.`kodexxkotkab`
LEFT JOIN `tblxxkelurahan` ON `tblxxkecamatan`.`kodexxkecamatan` = `tblxxkelurahan`.`kodexxkecamatan`
WHERE 1 = 1
AND  `tblxxkotkab`.`namaxxkotkab` LIKE '%%' ESCAPE '!'
 LIMIT 30
ERROR - 2020-02-19 06:07:07 --> Query error: Table 'rekam_medis.tblxxpropinsi' doesn't exist - Invalid query: SELECT `tblxxpropinsi`.`namaxxpropinsi` as `namaPropinsi`, `tblxxkotkab`.`namaxxkotkab` as `namaKotkab`, `tblxxkecamatan`.`namaxxkecamatan` as `namaKec`, `tblxxkelurahan`.`namaxxkelurahan` as `namaKel`
FROM `tblxxpropinsi`
LEFT JOIN `tblxxkotkab` ON `tblxxpropinsi`.`kodexxpropinsi` = `tblxxkotkab`.`kodexxpropinsi`
LEFT JOIN `tblxxkecamatan` ON `tblxxkotkab`.`kodexxkotkab` = `tblxxkecamatan`.`kodexxkotkab`
LEFT JOIN `tblxxkelurahan` ON `tblxxkecamatan`.`kodexxkecamatan` = `tblxxkelurahan`.`kodexxkecamatan`
WHERE 1 = 1
AND  `tblxxkotkab`.`namaxxkotkab` LIKE '%%' ESCAPE '!'
 LIMIT 30
ERROR - 2020-02-19 06:07:11 --> Query error: Table 'rekam_medis.tblxxpropinsi' doesn't exist - Invalid query: SELECT `tblxxpropinsi`.`namaxxpropinsi` as `namaPropinsi`, `tblxxkotkab`.`namaxxkotkab` as `namaKotkab`, `tblxxkecamatan`.`namaxxkecamatan` as `namaKec`, `tblxxkelurahan`.`namaxxkelurahan` as `namaKel`
FROM `tblxxpropinsi`
LEFT JOIN `tblxxkotkab` ON `tblxxpropinsi`.`kodexxpropinsi` = `tblxxkotkab`.`kodexxpropinsi`
LEFT JOIN `tblxxkecamatan` ON `tblxxkotkab`.`kodexxkotkab` = `tblxxkecamatan`.`kodexxkotkab`
LEFT JOIN `tblxxkelurahan` ON `tblxxkecamatan`.`kodexxkecamatan` = `tblxxkelurahan`.`kodexxkecamatan`
WHERE 1 = 1
AND  `tblxxkotkab`.`namaxxkotkab` LIKE '%%' ESCAPE '!'
 LIMIT 30
ERROR - 2020-02-19 06:07:13 --> Query error: Table 'rekam_medis.tblxxpropinsi' doesn't exist - Invalid query: SELECT `tblxxpropinsi`.`namaxxpropinsi` as `namaPropinsi`, `tblxxkotkab`.`namaxxkotkab` as `namaKotkab`, `tblxxkecamatan`.`namaxxkecamatan` as `namaKec`, `tblxxkelurahan`.`namaxxkelurahan` as `namaKel`
FROM `tblxxpropinsi`
LEFT JOIN `tblxxkotkab` ON `tblxxpropinsi`.`kodexxpropinsi` = `tblxxkotkab`.`kodexxpropinsi`
LEFT JOIN `tblxxkecamatan` ON `tblxxkotkab`.`kodexxkotkab` = `tblxxkecamatan`.`kodexxkotkab`
LEFT JOIN `tblxxkelurahan` ON `tblxxkecamatan`.`kodexxkecamatan` = `tblxxkelurahan`.`kodexxkecamatan`
WHERE 1 = 1
AND  `tblxxkotkab`.`namaxxkotkab` LIKE '%%' ESCAPE '!'
 LIMIT 30
ERROR - 2020-02-19 06:07:20 --> Query error: Table 'rekam_medis.tblxxpropinsi' doesn't exist - Invalid query: SELECT `tblxxpropinsi`.`namaxxpropinsi` as `namaPropinsi`, `tblxxkotkab`.`namaxxkotkab` as `namaKotkab`, `tblxxkecamatan`.`namaxxkecamatan` as `namaKec`, `tblxxkelurahan`.`namaxxkelurahan` as `namaKel`
FROM `tblxxpropinsi`
LEFT JOIN `tblxxkotkab` ON `tblxxpropinsi`.`kodexxpropinsi` = `tblxxkotkab`.`kodexxpropinsi`
LEFT JOIN `tblxxkecamatan` ON `tblxxkotkab`.`kodexxkotkab` = `tblxxkecamatan`.`kodexxkotkab`
LEFT JOIN `tblxxkelurahan` ON `tblxxkecamatan`.`kodexxkecamatan` = `tblxxkelurahan`.`kodexxkecamatan`
WHERE 1 = 1
AND  `tblxxkotkab`.`namaxxkotkab` LIKE '%%' ESCAPE '!'
 LIMIT 30
ERROR - 2020-02-19 06:08:59 --> Query error: Table 'rekam_medis.tblxxpropinsi' doesn't exist - Invalid query: SELECT `tblxxpropinsi`.`namaxxpropinsi` as `namaPropinsi`, `tblxxkotkab`.`namaxxkotkab` as `namaKotkab`, `tblxxkecamatan`.`namaxxkecamatan` as `namaKec`, `tblxxkelurahan`.`namaxxkelurahan` as `namaKel`
FROM `tblxxpropinsi`
LEFT JOIN `tblxxkotkab` ON `tblxxpropinsi`.`kodexxpropinsi` = `tblxxkotkab`.`kodexxpropinsi`
LEFT JOIN `tblxxkecamatan` ON `tblxxkotkab`.`kodexxkotkab` = `tblxxkecamatan`.`kodexxkotkab`
LEFT JOIN `tblxxkelurahan` ON `tblxxkecamatan`.`kodexxkecamatan` = `tblxxkelurahan`.`kodexxkecamatan`
WHERE 1 = 1
AND  `tblxxkotkab`.`namaxxkotkab` LIKE '%%' ESCAPE '!'
 LIMIT 30
ERROR - 2020-02-19 06:10:13 --> Query error: Table 'rekam_medis.tblxxpropinsi' doesn't exist - Invalid query: SELECT `tblxxpropinsi`.`namaxxpropinsi` as `namaPropinsi`, `tblxxkotkab`.`namaxxkotkab` as `namaKotkab`, `tblxxkecamatan`.`namaxxkecamatan` as `namaKec`, `tblxxkelurahan`.`namaxxkelurahan` as `namaKel`
FROM `tblxxpropinsi`
LEFT JOIN `tblxxkotkab` ON `tblxxpropinsi`.`kodexxpropinsi` = `tblxxkotkab`.`kodexxpropinsi`
LEFT JOIN `tblxxkecamatan` ON `tblxxkotkab`.`kodexxkotkab` = `tblxxkecamatan`.`kodexxkotkab`
LEFT JOIN `tblxxkelurahan` ON `tblxxkecamatan`.`kodexxkecamatan` = `tblxxkelurahan`.`kodexxkecamatan`
WHERE 1 = 1
AND  `tblxxkotkab`.`namaxxkotkab` LIKE '%%' ESCAPE '!'
 LIMIT 30
ERROR - 2020-02-19 06:15:42 --> Query error: Table 'rekam_medis.tblxxpropinsi' doesn't exist - Invalid query: SELECT `tblxxpropinsi`.`namaxxpropinsi` as `namaPropinsi`, `tblxxkotkab`.`namaxxkotkab` as `namaKotkab`, `tblxxkecamatan`.`namaxxkecamatan` as `namaKec`, `tblxxkelurahan`.`namaxxkelurahan` as `namaKel`
FROM `tblxxpropinsi`
LEFT JOIN `tblxxkotkab` ON `tblxxpropinsi`.`kodexxpropinsi` = `tblxxkotkab`.`kodexxpropinsi`
LEFT JOIN `tblxxkecamatan` ON `tblxxkotkab`.`kodexxkotkab` = `tblxxkecamatan`.`kodexxkotkab`
LEFT JOIN `tblxxkelurahan` ON `tblxxkecamatan`.`kodexxkecamatan` = `tblxxkelurahan`.`kodexxkecamatan`
WHERE 1 = 1
AND  `tblxxkotkab`.`namaxxkotkab` LIKE '%%' ESCAPE '!'
 LIMIT 30
ERROR - 2020-02-19 06:16:45 --> Query error: Table 'rekam_medis.tblxxpropinsi' doesn't exist - Invalid query: SELECT `tblxxpropinsi`.`namaxxpropinsi` as `namaPropinsi`, `tblxxkotkab`.`namaxxkotkab` as `namaKotkab`, `tblxxkecamatan`.`namaxxkecamatan` as `namaKec`, `tblxxkelurahan`.`namaxxkelurahan` as `namaKel`
FROM `tblxxpropinsi`
LEFT JOIN `tblxxkotkab` ON `tblxxpropinsi`.`kodexxpropinsi` = `tblxxkotkab`.`kodexxpropinsi`
LEFT JOIN `tblxxkecamatan` ON `tblxxkotkab`.`kodexxkotkab` = `tblxxkecamatan`.`kodexxkotkab`
LEFT JOIN `tblxxkelurahan` ON `tblxxkecamatan`.`kodexxkecamatan` = `tblxxkelurahan`.`kodexxkecamatan`
WHERE 1 = 1
AND  `tblxxkotkab`.`namaxxkotkab` LIKE '%%' ESCAPE '!'
 LIMIT 30
ERROR - 2020-02-19 06:18:32 --> Query error: Table 'rekam_medis.tblxxpropinsi' doesn't exist - Invalid query: SELECT `tblxxpropinsi`.`namaxxpropinsi` as `namaPropinsi`, `tblxxkotkab`.`namaxxkotkab` as `namaKotkab`, `tblxxkecamatan`.`namaxxkecamatan` as `namaKec`, `tblxxkelurahan`.`namaxxkelurahan` as `namaKel`
FROM `tblxxpropinsi`
LEFT JOIN `tblxxkotkab` ON `tblxxpropinsi`.`kodexxpropinsi` = `tblxxkotkab`.`kodexxpropinsi`
LEFT JOIN `tblxxkecamatan` ON `tblxxkotkab`.`kodexxkotkab` = `tblxxkecamatan`.`kodexxkotkab`
LEFT JOIN `tblxxkelurahan` ON `tblxxkecamatan`.`kodexxkecamatan` = `tblxxkelurahan`.`kodexxkecamatan`
WHERE 1 = 1
AND  `tblxxkotkab`.`namaxxkotkab` LIKE '%%' ESCAPE '!'
 LIMIT 30
ERROR - 2020-02-19 06:19:17 --> Query error: Table 'rekam_medis.tblxxpropinsi' doesn't exist - Invalid query: SELECT `tblxxpropinsi`.`namaxxpropinsi` as `namaPropinsi`, `tblxxkotkab`.`namaxxkotkab` as `namaKotkab`, `tblxxkecamatan`.`namaxxkecamatan` as `namaKec`, `tblxxkelurahan`.`namaxxkelurahan` as `namaKel`
FROM `tblxxpropinsi`
LEFT JOIN `tblxxkotkab` ON `tblxxpropinsi`.`kodexxpropinsi` = `tblxxkotkab`.`kodexxpropinsi`
LEFT JOIN `tblxxkecamatan` ON `tblxxkotkab`.`kodexxkotkab` = `tblxxkecamatan`.`kodexxkotkab`
LEFT JOIN `tblxxkelurahan` ON `tblxxkecamatan`.`kodexxkecamatan` = `tblxxkelurahan`.`kodexxkecamatan`
WHERE 1 = 1
AND  `tblxxkotkab`.`namaxxkotkab` LIKE '%%' ESCAPE '!'
 LIMIT 30
ERROR - 2020-02-19 06:19:43 --> Query error: Table 'rekam_medis.tblxxpropinsi' doesn't exist - Invalid query: SELECT `tblxxpropinsi`.`namaxxpropinsi` as `namaPropinsi`, `tblxxkotkab`.`namaxxkotkab` as `namaKotkab`, `tblxxkecamatan`.`namaxxkecamatan` as `namaKec`, `tblxxkelurahan`.`namaxxkelurahan` as `namaKel`
FROM `tblxxpropinsi`
LEFT JOIN `tblxxkotkab` ON `tblxxpropinsi`.`kodexxpropinsi` = `tblxxkotkab`.`kodexxpropinsi`
LEFT JOIN `tblxxkecamatan` ON `tblxxkotkab`.`kodexxkotkab` = `tblxxkecamatan`.`kodexxkotkab`
LEFT JOIN `tblxxkelurahan` ON `tblxxkecamatan`.`kodexxkecamatan` = `tblxxkelurahan`.`kodexxkecamatan`
WHERE 1 = 1
AND  `tblxxkotkab`.`namaxxkotkab` LIKE '%%' ESCAPE '!'
 LIMIT 30
ERROR - 2020-02-19 06:22:29 --> Query error: Table 'rekam_medis.tblxxpropinsi' doesn't exist - Invalid query: SELECT `tblxxpropinsi`.`namaxxpropinsi` as `namaPropinsi`, `tblxxkotkab`.`namaxxkotkab` as `namaKotkab`, `tblxxkecamatan`.`namaxxkecamatan` as `namaKec`, `tblxxkelurahan`.`namaxxkelurahan` as `namaKel`
FROM `tblxxpropinsi`
LEFT JOIN `tblxxkotkab` ON `tblxxpropinsi`.`kodexxpropinsi` = `tblxxkotkab`.`kodexxpropinsi`
LEFT JOIN `tblxxkecamatan` ON `tblxxkotkab`.`kodexxkotkab` = `tblxxkecamatan`.`kodexxkotkab`
LEFT JOIN `tblxxkelurahan` ON `tblxxkecamatan`.`kodexxkecamatan` = `tblxxkelurahan`.`kodexxkecamatan`
WHERE 1 = 1
AND  `tblxxkotkab`.`namaxxkotkab` LIKE '%%' ESCAPE '!'
 LIMIT 30
ERROR - 2020-02-19 06:37:24 --> Query error: Table 'rekam_medis.tblxxpropinsi' doesn't exist - Invalid query: SELECT `tblxxpropinsi`.`namaxxpropinsi` as `namaPropinsi`, `tblxxkotkab`.`namaxxkotkab` as `namaKotkab`, `tblxxkecamatan`.`namaxxkecamatan` as `namaKec`, `tblxxkelurahan`.`namaxxkelurahan` as `namaKel`
FROM `tblxxpropinsi`
LEFT JOIN `tblxxkotkab` ON `tblxxpropinsi`.`kodexxpropinsi` = `tblxxkotkab`.`kodexxpropinsi`
LEFT JOIN `tblxxkecamatan` ON `tblxxkotkab`.`kodexxkotkab` = `tblxxkecamatan`.`kodexxkotkab`
LEFT JOIN `tblxxkelurahan` ON `tblxxkecamatan`.`kodexxkecamatan` = `tblxxkelurahan`.`kodexxkecamatan`
WHERE 1 = 1
AND  `tblxxkotkab`.`namaxxkotkab` LIKE '%%' ESCAPE '!'
 LIMIT 30
ERROR - 2020-02-19 06:37:30 --> Query error: Table 'rekam_medis.tblxxpropinsi' doesn't exist - Invalid query: SELECT `tblxxpropinsi`.`namaxxpropinsi` as `namaPropinsi`, `tblxxkotkab`.`namaxxkotkab` as `namaKotkab`, `tblxxkecamatan`.`namaxxkecamatan` as `namaKec`, `tblxxkelurahan`.`namaxxkelurahan` as `namaKel`
FROM `tblxxpropinsi`
LEFT JOIN `tblxxkotkab` ON `tblxxpropinsi`.`kodexxpropinsi` = `tblxxkotkab`.`kodexxpropinsi`
LEFT JOIN `tblxxkecamatan` ON `tblxxkotkab`.`kodexxkotkab` = `tblxxkecamatan`.`kodexxkotkab`
LEFT JOIN `tblxxkelurahan` ON `tblxxkecamatan`.`kodexxkecamatan` = `tblxxkelurahan`.`kodexxkecamatan`
WHERE 1 = 1
AND  `tblxxkotkab`.`namaxxkotkab` LIKE '%%' ESCAPE '!'
 LIMIT 30
ERROR - 2020-02-19 06:37:34 --> Query error: Table 'rekam_medis.tblxxpropinsi' doesn't exist - Invalid query: SELECT `tblxxpropinsi`.`namaxxpropinsi` as `namaPropinsi`, `tblxxkotkab`.`namaxxkotkab` as `namaKotkab`, `tblxxkecamatan`.`namaxxkecamatan` as `namaKec`, `tblxxkelurahan`.`namaxxkelurahan` as `namaKel`
FROM `tblxxpropinsi`
LEFT JOIN `tblxxkotkab` ON `tblxxpropinsi`.`kodexxpropinsi` = `tblxxkotkab`.`kodexxpropinsi`
LEFT JOIN `tblxxkecamatan` ON `tblxxkotkab`.`kodexxkotkab` = `tblxxkecamatan`.`kodexxkotkab`
LEFT JOIN `tblxxkelurahan` ON `tblxxkecamatan`.`kodexxkecamatan` = `tblxxkelurahan`.`kodexxkecamatan`
WHERE 1 = 1
AND  `tblxxkotkab`.`namaxxkotkab` LIKE '%%' ESCAPE '!'
 LIMIT 30
ERROR - 2020-02-19 06:37:37 --> Query error: Table 'rekam_medis.tblxxpropinsi' doesn't exist - Invalid query: SELECT `tblxxpropinsi`.`namaxxpropinsi` as `namaPropinsi`, `tblxxkotkab`.`namaxxkotkab` as `namaKotkab`, `tblxxkecamatan`.`namaxxkecamatan` as `namaKec`, `tblxxkelurahan`.`namaxxkelurahan` as `namaKel`
FROM `tblxxpropinsi`
LEFT JOIN `tblxxkotkab` ON `tblxxpropinsi`.`kodexxpropinsi` = `tblxxkotkab`.`kodexxpropinsi`
LEFT JOIN `tblxxkecamatan` ON `tblxxkotkab`.`kodexxkotkab` = `tblxxkecamatan`.`kodexxkotkab`
LEFT JOIN `tblxxkelurahan` ON `tblxxkecamatan`.`kodexxkecamatan` = `tblxxkelurahan`.`kodexxkecamatan`
WHERE 1 = 1
AND  `tblxxkotkab`.`namaxxkotkab` LIKE '%%' ESCAPE '!'
 LIMIT 30
ERROR - 2020-02-19 06:38:36 --> Query error: Table 'rekam_medis.tblxxpropinsi' doesn't exist - Invalid query: SELECT `tblxxpropinsi`.`namaxxpropinsi` as `namaPropinsi`, `tblxxkotkab`.`namaxxkotkab` as `namaKotkab`, `tblxxkecamatan`.`namaxxkecamatan` as `namaKec`, `tblxxkelurahan`.`namaxxkelurahan` as `namaKel`
FROM `tblxxpropinsi`
LEFT JOIN `tblxxkotkab` ON `tblxxpropinsi`.`kodexxpropinsi` = `tblxxkotkab`.`kodexxpropinsi`
LEFT JOIN `tblxxkecamatan` ON `tblxxkotkab`.`kodexxkotkab` = `tblxxkecamatan`.`kodexxkotkab`
LEFT JOIN `tblxxkelurahan` ON `tblxxkecamatan`.`kodexxkecamatan` = `tblxxkelurahan`.`kodexxkecamatan`
WHERE 1 = 1
AND  `tblxxkotkab`.`namaxxkotkab` LIKE '%%' ESCAPE '!'
 LIMIT 30
ERROR - 2020-02-19 06:38:44 --> Query error: Table 'rekam_medis.tblxxpropinsi' doesn't exist - Invalid query: SELECT `tblxxpropinsi`.`namaxxpropinsi` as `namaPropinsi`, `tblxxkotkab`.`namaxxkotkab` as `namaKotkab`, `tblxxkecamatan`.`namaxxkecamatan` as `namaKec`, `tblxxkelurahan`.`namaxxkelurahan` as `namaKel`
FROM `tblxxpropinsi`
LEFT JOIN `tblxxkotkab` ON `tblxxpropinsi`.`kodexxpropinsi` = `tblxxkotkab`.`kodexxpropinsi`
LEFT JOIN `tblxxkecamatan` ON `tblxxkotkab`.`kodexxkotkab` = `tblxxkecamatan`.`kodexxkotkab`
LEFT JOIN `tblxxkelurahan` ON `tblxxkecamatan`.`kodexxkecamatan` = `tblxxkelurahan`.`kodexxkecamatan`
WHERE 1 = 1
AND  `tblxxkotkab`.`namaxxkotkab` LIKE '%%' ESCAPE '!'
 LIMIT 30
ERROR - 2020-02-19 06:38:49 --> Query error: Table 'rekam_medis.tblxxpropinsi' doesn't exist - Invalid query: SELECT `tblxxpropinsi`.`namaxxpropinsi` as `namaPropinsi`, `tblxxkotkab`.`namaxxkotkab` as `namaKotkab`, `tblxxkecamatan`.`namaxxkecamatan` as `namaKec`, `tblxxkelurahan`.`namaxxkelurahan` as `namaKel`
FROM `tblxxpropinsi`
LEFT JOIN `tblxxkotkab` ON `tblxxpropinsi`.`kodexxpropinsi` = `tblxxkotkab`.`kodexxpropinsi`
LEFT JOIN `tblxxkecamatan` ON `tblxxkotkab`.`kodexxkotkab` = `tblxxkecamatan`.`kodexxkotkab`
LEFT JOIN `tblxxkelurahan` ON `tblxxkecamatan`.`kodexxkecamatan` = `tblxxkelurahan`.`kodexxkecamatan`
WHERE 1 = 1
AND  `tblxxkotkab`.`namaxxkotkab` LIKE '%%' ESCAPE '!'
 LIMIT 30
ERROR - 2020-02-19 06:42:00 --> Severity: error --> Exception: Call to a member function get_nested() on null D:\webserver@raka\htdocs\rekam_medis\application\libraries\Admin_Controller.php 56
ERROR - 2020-02-19 06:42:16 --> Severity: error --> Exception: Call to a member function get() on null D:\webserver@raka\htdocs\rekam_medis\application\controllers\backoffice\Dashboard.php 16
ERROR - 2020-02-19 06:43:09 --> Query error: Table 'rekam_medis.tblxxpropinsi' doesn't exist - Invalid query: SELECT `tblxxpropinsi`.`namaxxpropinsi` as `namaPropinsi`, `tblxxkotkab`.`namaxxkotkab` as `namaKotkab`, `tblxxkecamatan`.`namaxxkecamatan` as `namaKec`, `tblxxkelurahan`.`namaxxkelurahan` as `namaKel`
FROM `tblxxpropinsi`
LEFT JOIN `tblxxkotkab` ON `tblxxpropinsi`.`kodexxpropinsi` = `tblxxkotkab`.`kodexxpropinsi`
LEFT JOIN `tblxxkecamatan` ON `tblxxkotkab`.`kodexxkotkab` = `tblxxkecamatan`.`kodexxkotkab`
LEFT JOIN `tblxxkelurahan` ON `tblxxkecamatan`.`kodexxkecamatan` = `tblxxkelurahan`.`kodexxkecamatan`
WHERE 1 = 1
AND  `tblxxkotkab`.`namaxxkotkab` LIKE '%%' ESCAPE '!'
 LIMIT 30
ERROR - 2020-02-19 06:43:45 --> Severity: error --> Exception: Call to a member function getWilayah() on null D:\webserver@raka\htdocs\rekam_medis\application\controllers\backoffice\Crdomestic.php 100
ERROR - 2020-02-19 06:43:53 --> Severity: error --> Exception: Call to a member function getWilayah() on null D:\webserver@raka\htdocs\rekam_medis\application\controllers\backoffice\Crdomestic.php 100
ERROR - 2020-02-19 06:44:09 --> Severity: error --> Exception: Call to a member function get() on null D:\webserver@raka\htdocs\rekam_medis\application\controllers\backoffice\Dashboard.php 16
ERROR - 2020-02-19 06:44:18 --> Severity: error --> Exception: Call to a member function get() on null D:\webserver@raka\htdocs\rekam_medis\application\controllers\backoffice\Dashboard.php 16
ERROR - 2020-02-19 06:44:26 --> Severity: error --> Exception: Call to a member function getWilayah() on null D:\webserver@raka\htdocs\rekam_medis\application\controllers\backoffice\Crdomestic.php 100
ERROR - 2020-02-19 06:44:30 --> Severity: error --> Exception: Call to a member function get() on null D:\webserver@raka\htdocs\rekam_medis\application\controllers\backoffice\Dashboard.php 16
ERROR - 2020-02-19 06:44:52 --> Severity: error --> Exception: Call to a member function get_with_join() on null D:\webserver@raka\htdocs\rekam_medis\application\controllers\backoffice\Dashboard.php 18
ERROR - 2020-02-19 06:45:39 --> Severity: error --> Exception: Call to a member function getWilayah() on null D:\webserver@raka\htdocs\rekam_medis\application\controllers\backoffice\Crdomestic.php 100
ERROR - 2020-02-19 06:45:51 --> Severity: error --> Exception: Call to a member function getWilayah() on null D:\webserver@raka\htdocs\rekam_medis\application\controllers\backoffice\Crdomestic.php 100
ERROR - 2020-02-19 06:51:52 --> Severity: error --> Exception: Call to a member function query() on unknown D:\webserver@raka\htdocs\rekam_medis\application\views\backoffice\dashboard\grafikbatang.php 45
ERROR - 2020-02-19 06:51:52 --> Severity: error --> Exception: Call to a member function getWilayah() on null D:\webserver@raka\htdocs\rekam_medis\application\controllers\backoffice\Crdomestic.php 100
ERROR - 2020-02-19 06:52:21 --> Severity: error --> Exception: Call to a member function getWilayah() on null D:\webserver@raka\htdocs\rekam_medis\application\controllers\backoffice\Crdomestic.php 100
ERROR - 2020-02-19 06:52:21 --> Severity: error --> Exception: Call to a member function query() on unknown D:\webserver@raka\htdocs\rekam_medis\application\views\backoffice\dashboard\grafikbatang.php 45
ERROR - 2020-02-19 06:53:39 --> Severity: error --> Exception: Call to a member function getWilayah() on null D:\webserver@raka\htdocs\rekam_medis\application\controllers\backoffice\Crdomestic.php 100
ERROR - 2020-02-19 06:53:55 --> Severity: error --> Exception: Call to a member function getWilayah() on null D:\webserver@raka\htdocs\rekam_medis\application\controllers\backoffice\Crdomestic.php 100
ERROR - 2020-02-19 06:54:10 --> Severity: error --> Exception: Call to a member function getWilayah() on null D:\webserver@raka\htdocs\rekam_medis\application\controllers\backoffice\Crdomestic.php 100
ERROR - 2020-02-19 06:54:23 --> Severity: error --> Exception: Call to a member function getWilayah() on null D:\webserver@raka\htdocs\rekam_medis\application\controllers\backoffice\Crdomestic.php 100
ERROR - 2020-02-19 06:58:02 --> Severity: error --> Exception: Call to a member function query() on unknown D:\webserver@raka\htdocs\rekam_medis\application\views\backoffice\dashboard\grafikbatang.php 45
ERROR - 2020-02-19 06:59:07 --> Severity: error --> Exception: Call to a member function query() on unknown D:\webserver@raka\htdocs\rekam_medis\application\views\backoffice\dashboard\grafikbatang.php 45
ERROR - 2020-02-19 07:00:00 --> Severity: error --> Exception: Call to a member function query() on unknown D:\webserver@raka\htdocs\rekam_medis\application\views\backoffice\dashboard\grafikbatang.php 45
ERROR - 2020-02-19 07:00:16 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) D:\webserver@raka\htdocs\rekam_medis\application\views\backoffice\dashboard\grafikbatang.php 1
ERROR - 2020-02-19 07:00:28 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) D:\webserver@raka\htdocs\rekam_medis\application\views\backoffice\dashboard\grafikbatang.php 1
ERROR - 2020-02-19 07:00:47 --> Severity: error --> Exception: Call to a member function query() on unknown D:\webserver@raka\htdocs\rekam_medis\application\views\backoffice\dashboard\grafikbatang.php 45
ERROR - 2020-02-19 07:10:04 --> Severity: error --> Exception: Call to a member function query() on unknown D:\webserver@raka\htdocs\rekam_medis\application\views\backoffice\dashboard\grafikbatang.php 44
ERROR - 2020-02-19 07:10:23 --> Severity: error --> Exception: Call to a member function query() on unknown D:\webserver@raka\htdocs\rekam_medis\application\views\backoffice\dashboard\grafikbatang.php 44
ERROR - 2020-02-19 08:19:14 --> Query error: Unknown column 'tgldirectory' in 'where clause' - Invalid query: SELECT *
FROM `tblpromointr`
WHERE YEAR(tgldirectory) = '2019'
ORDER BY `idpromointr` DESC
ERROR - 2020-02-19 08:52:28 --> Severity: error --> Exception: Call to a member function get_by() on null D:\webserver@raka\htdocs\rekam_medis\application\controllers\backoffice\Dashboard.php 61
ERROR - 2020-02-19 08:52:33 --> Severity: error --> Exception: Call to a member function get_by() on null D:\webserver@raka\htdocs\rekam_medis\application\controllers\backoffice\Dashboard.php 61
ERROR - 2020-02-19 08:52:49 --> Severity: error --> Exception: Call to a member function get_by() on null D:\webserver@raka\htdocs\rekam_medis\application\controllers\backoffice\Dashboard.php 61
ERROR - 2020-02-19 08:53:11 --> Severity: error --> Exception: Call to a member function get_by() on null D:\webserver@raka\htdocs\rekam_medis\application\controllers\backoffice\Dashboard.php 61
ERROR - 2020-02-19 09:09:15 --> Severity: error --> Exception: Call to a member function get_by() on null D:\webserver@raka\htdocs\rekam_medis\application\controllers\backoffice\Dashboard.php 62
ERROR - 2020-02-19 09:09:41 --> Severity: error --> Exception: Call to a member function get_by() on null D:\webserver@raka\htdocs\rekam_medis\application\controllers\backoffice\Dashboard.php 62
ERROR - 2020-02-19 09:10:14 --> Query error: Column 'modified' in order clause is ambiguous - Invalid query: SELECT *
FROM `t_pasien`
LEFT JOIN `t_directory` ON `t_pasien`.`iddirectory` = `t_directory`.`id`
WHERE MONTH(t_directory.tgldirectory) = 1
ORDER BY `modified` DESC
ERROR - 2020-02-19 09:12:27 --> Query error: Unknown column 't_berkas.modified' in 'order clause' - Invalid query: SELECT *
FROM `t_directory`
WHERE MONTH(tgldirectory) = 1
ORDER BY `t_berkas`.`modified` DESC
ERROR - 2020-02-19 10:34:42 --> Query error: Unknown column 'tgldirectory' in 'group statement' - Invalid query: SELECT *
FROM `logis_users`
WHERE `iduser` = 1
GROUP BY `tgldirectory`
ORDER BY `modified` DESC
ERROR - 2020-02-19 10:37:08 --> Query error: Unknown column 'tgldirectory' in 'group statement' - Invalid query: SELECT *
FROM `logis_users`
WHERE `iduser` = 1
GROUP BY `tgldirectory`
ORDER BY `modified` DESC
ERROR - 2020-02-19 10:41:42 --> Query error: Unknown column 'tgldirectory' in 'group statement' - Invalid query: SELECT *
FROM `logis_users`
WHERE `iduser` = 1
GROUP BY `tgldirectory`
ORDER BY `modified` DESC
ERROR - 2020-02-19 10:41:57 --> Query error: Unknown column 'tgldirectory' in 'group statement' - Invalid query: SELECT *
FROM `logis_users`
WHERE `iduser` = 1
GROUP BY `tgldirectory`
ORDER BY `modified` DESC
ERROR - 2020-02-19 10:43:15 --> Query error: Unknown column 'tgldirectory' in 'group statement' - Invalid query: SELECT *
FROM `logis_users`
WHERE `iduser` = 1
GROUP BY `tgldirectory`
ORDER BY `modified` DESC
ERROR - 2020-02-19 11:05:06 --> Severity: error --> Exception: syntax error, unexpected 'for' (T_FOR) D:\webserver@raka\htdocs\rekam_medis\application\controllers\backoffice\Dashboard.php 45
ERROR - 2020-02-19 11:06:02 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' D:\webserver@raka\htdocs\rekam_medis\application\controllers\backoffice\Dashboard.php 49
ERROR - 2020-02-19 11:25:41 --> Query error: Unknown column 't_directory.tgldirectory' in 'where clause' - Invalid query: SELECT *
FROM `t_pasien`
WHERE MONTH(t_directory.tgldirectory) = 1
AND YEAR(t_directory.tgldirectory) = '2020'
AND `t_pasien`.`jeniskelamin` = 'P'
ORDER BY `t_pasien`.`modified` DESC
ERROR - 2020-02-19 11:26:26 --> Query error: Unknown column 't_directory.tgldirectory' in 'where clause' - Invalid query: SELECT *
FROM `t_pasien`
WHERE MONTH(t_directory.tgldirectory) = 1
AND YEAR(t_directory.tgldirectory) = '2020'
AND `t_pasien`.`jeniskelamin` = 'P'
ORDER BY `t_pasien`.`modified` DESC
ERROR - 2020-02-19 11:26:51 --> Query error: Unknown column 't_directory.tgldirectory' in 'where clause' - Invalid query: SELECT *
FROM `t_pasien`
WHERE MONTH(t_directory.tgldirectory) = 1
AND YEAR(t_directory.tgldirectory) = '2020'
AND `t_pasien`.`jeniskelamin` = 'P'
ORDER BY `t_pasien`.`modified` DESC
ERROR - 2020-02-19 12:05:48 --> Severity: error --> Exception: Call to a member function query() on unknown D:\webserver@raka\htdocs\rekam_medis\application\views\backoffice\dashboard\grafikpie.php 11
ERROR - 2020-02-19 12:15:29 --> Severity: error --> Exception: Call to a member function query() on unknown D:\webserver@raka\htdocs\rekam_medis\application\views\backoffice\dashboard\grafikpie.php 11
ERROR - 2020-02-19 12:18:02 --> Severity: error --> Exception: Call to a member function query() on unknown D:\webserver@raka\htdocs\rekam_medis\application\views\backoffice\dashboard\grafikpie.php 11
ERROR - 2020-02-19 12:19:10 --> Severity: error --> Exception: Call to a member function query() on unknown D:\webserver@raka\htdocs\rekam_medis\application\views\backoffice\dashboard\grafikpie.php 11
