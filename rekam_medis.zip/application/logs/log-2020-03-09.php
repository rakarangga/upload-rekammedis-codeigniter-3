<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-09 02:29:42 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `t_pasien`
WHERE `id` not in (Array)
ORDER BY `t_pasien`.`modified` DESC
ERROR - 2020-03-09 03:30:07 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 71
ERROR - 2020-03-09 03:31:32 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 71
ERROR - 2020-03-09 03:31:41 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 71
ERROR - 2020-03-09 03:32:05 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 71
ERROR - 2020-03-09 03:32:21 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 114
ERROR - 2020-03-09 03:32:27 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 71
ERROR - 2020-03-09 03:32:27 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 114
ERROR - 2020-03-09 03:34:23 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 114
ERROR - 2020-03-09 03:34:24 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 71
ERROR - 2020-03-09 03:34:28 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 114
ERROR - 2020-03-09 03:34:29 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 71
ERROR - 2020-03-09 03:34:58 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 71
ERROR - 2020-03-09 03:34:58 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 114
ERROR - 2020-03-09 03:41:10 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 114
ERROR - 2020-03-09 03:41:10 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 71
ERROR - 2020-03-09 03:57:09 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 71
ERROR - 2020-03-09 03:57:09 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 114
ERROR - 2020-03-09 04:18:07 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 71
ERROR - 2020-03-09 04:18:07 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 114
ERROR - 2020-03-09 07:21:00 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 114
ERROR - 2020-03-09 07:21:00 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 71
ERROR - 2020-03-09 08:05:06 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 114
ERROR - 2020-03-09 08:05:06 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 71
ERROR - 2020-03-09 08:05:11 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 114
ERROR - 2020-03-09 08:05:11 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 71
ERROR - 2020-03-09 08:09:37 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 114
ERROR - 2020-03-09 08:09:37 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 71
ERROR - 2020-03-09 08:15:27 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 114
ERROR - 2020-03-09 08:15:27 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 71
ERROR - 2020-03-09 08:22:50 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 71
ERROR - 2020-03-09 08:22:50 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 114
ERROR - 2020-03-09 08:23:15 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 71
ERROR - 2020-03-09 08:23:15 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 114
ERROR - 2020-03-09 08:23:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
ORDER BY `t_pasien`.`modified` DESC' at line 3 - Invalid query: SELECT *
FROM `t_pasien`
WHERE `stts` = 1 AND  `id` NOT IN ()
ORDER BY `t_pasien`.`modified` DESC
ERROR - 2020-03-09 08:23:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
ORDER BY `t_pasien`.`modified` DESC' at line 3 - Invalid query: SELECT *
FROM `t_pasien`
WHERE `stts` = 1 AND  `id` NOT IN ()
ORDER BY `t_pasien`.`modified` DESC
ERROR - 2020-03-09 08:24:01 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 114
ERROR - 2020-03-09 08:24:01 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 71
ERROR - 2020-03-09 08:24:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*) AS *
FROM `t_pasien`
WHERE `stts` = 1 AND  `id` NOT IN (86,85,84,83,82)' at line 1 - Invalid query: SELECT SUM(*) AS *
FROM `t_pasien`
WHERE `stts` = 1 AND  `id` NOT IN (86,85,84,83,82)
ERROR - 2020-03-09 08:25:09 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 71
ERROR - 2020-03-09 08:25:09 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 114
ERROR - 2020-03-09 08:25:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*) AS *
FROM `t_pasien`' at line 1 - Invalid query: SELECT SUM(*) AS *
FROM `t_pasien`
ERROR - 2020-03-09 08:25:40 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 71
ERROR - 2020-03-09 08:25:40 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 114
ERROR - 2020-03-09 08:25:54 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 71
ERROR - 2020-03-09 08:25:54 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 114
ERROR - 2020-03-09 08:26:35 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 114
ERROR - 2020-03-09 08:26:35 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 71
ERROR - 2020-03-09 08:27:22 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 114
ERROR - 2020-03-09 08:27:22 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 71
ERROR - 2020-03-09 08:29:06 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 114
ERROR - 2020-03-09 08:29:07 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 71
ERROR - 2020-03-09 08:29:26 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 71
ERROR - 2020-03-09 08:29:27 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 114
ERROR - 2020-03-09 08:34:39 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 71
ERROR - 2020-03-09 08:34:39 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 114
ERROR - 2020-03-09 08:34:54 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 114
ERROR - 2020-03-09 08:34:55 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 71
ERROR - 2020-03-09 08:36:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*) AS `count`
FROM `t_pasien`
WHERE `stts` = 1 AND  `id` NOT IN (86,85,84,83,82)' at line 1 - Invalid query: SELECT SUM(*) AS `count`
FROM `t_pasien`
WHERE `stts` = 1 AND  `id` NOT IN (86,85,84,83,82)
ERROR - 2020-03-09 08:36:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*) AS `count`
FROM `t_pasien`
WHERE `stts` = 1 AND  `id` NOT IN (86,85,84,83,82)' at line 1 - Invalid query: SELECT SUM(*) AS `count`
FROM `t_pasien`
WHERE `stts` = 1 AND  `id` NOT IN (86,85,84,83,82)
ERROR - 2020-03-09 08:36:54 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 71
ERROR - 2020-03-09 08:36:54 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 114
ERROR - 2020-03-09 08:36:54 --> Severity: error --> Exception: Cannot use object of type CI_DB_mysqli_result as array D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 183
ERROR - 2020-03-09 08:37:12 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 114
ERROR - 2020-03-09 08:37:13 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 71
ERROR - 2020-03-09 08:37:35 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 114
ERROR - 2020-03-09 08:37:35 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 71
ERROR - 2020-03-09 08:42:16 --> Severity: error --> Exception: Cannot use object of type CI_DB_mysqli_result as array D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 183
ERROR - 2020-03-09 08:42:56 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 71
ERROR - 2020-03-09 08:42:56 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 114
ERROR - 2020-03-09 08:43:35 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 71
ERROR - 2020-03-09 08:43:35 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 114
ERROR - 2020-03-09 08:46:57 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 183
ERROR - 2020-03-09 08:47:13 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 183
ERROR - 2020-03-09 08:47:53 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 114
ERROR - 2020-03-09 08:47:53 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 71
ERROR - 2020-03-09 08:50:03 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 114
ERROR - 2020-03-09 08:50:03 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 71
ERROR - 2020-03-09 08:50:24 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 71
ERROR - 2020-03-09 08:50:24 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 114
ERROR - 2020-03-09 08:50:50 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 71
ERROR - 2020-03-09 08:50:51 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 114
ERROR - 2020-03-09 08:51:15 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 114
ERROR - 2020-03-09 08:51:15 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 71
ERROR - 2020-03-09 08:52:05 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 71
ERROR - 2020-03-09 08:52:05 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 114
ERROR - 2020-03-09 08:52:20 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 114
ERROR - 2020-03-09 08:52:20 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 71
ERROR - 2020-03-09 08:53:23 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 71
ERROR - 2020-03-09 08:53:24 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 114
ERROR - 2020-03-09 08:53:31 --> Query error: Unknown column 'alias' in 'field list' - Invalid query: SELECT SUM(`alias`) AS `alias`
FROM `t_pasien`
WHERE `stts` = 1 AND  `id` NOT IN (86,85,84,83,82)
ORDER BY `t_pasien`.`modified` DESC
ERROR - 2020-03-09 08:54:03 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 71
ERROR - 2020-03-09 08:54:04 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 114
ERROR - 2020-03-09 08:54:28 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 114
ERROR - 2020-03-09 08:54:28 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 71
ERROR - 2020-03-09 08:55:42 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 114
ERROR - 2020-03-09 08:55:42 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 71
ERROR - 2020-03-09 08:56:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*) AS *
FROM `t_pasien`
WHERE `stts` = 1 AND  `id` NOT IN (86,85,84,83,82)
ORDER' at line 1 - Invalid query: SELECT SUM(*) AS *
FROM `t_pasien`
WHERE `stts` = 1 AND  `id` NOT IN (86,85,84,83,82)
ORDER BY `t_pasien`.`modified` DESC
ERROR - 2020-03-09 08:56:09 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 114
ERROR - 2020-03-09 08:56:09 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 71
ERROR - 2020-03-09 08:56:30 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 114
ERROR - 2020-03-09 08:56:31 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 71
ERROR - 2020-03-09 08:56:48 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 71
ERROR - 2020-03-09 08:56:49 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 114
ERROR - 2020-03-09 08:57:00 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 71
ERROR - 2020-03-09 08:57:01 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 114
ERROR - 2020-03-09 08:57:22 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 71
ERROR - 2020-03-09 08:57:22 --> Severity: Error --> Maximum execution time of 40 seconds exceeded D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 114
