<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-06 23:58:27 --> Severity: Error --> Out of memory (allocated 2097152) (tried to allocate 8192 bytes) D:\webserver@raka\htdocs\__2020\rekam_medis\system\database\DB_query_builder.php 677
