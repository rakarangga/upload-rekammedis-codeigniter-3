<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-20 07:25:31 --> Query error: Unknown column 't_directory.tgldirectory' in 'where clause' - Invalid query: SELECT *
FROM `t_pasien`
WHERE MONTH(t_directory.tgldirectory) = 1
AND YEAR(t_directory.tgldirectory) = '2020'
AND `t_pasien`.`jeniskelamin` = 'L'
ORDER BY `t_pasien`.`modified` DESC
ERROR - 2020-02-20 07:26:06 --> Query error: Unknown column 't_directory.tgldirectory' in 'where clause' - Invalid query: SELECT *
FROM `t_pasien`
WHERE MONTH(t_directory.tgldirectory) = 1
AND YEAR(t_directory.tgldirectory) = '2020'
AND `t_pasien`.`jeniskelamin` = 'L'
ORDER BY `t_pasien`.`modified` DESC
ERROR - 2020-02-20 07:26:55 --> Query error: Unknown column 't_directory.tgldirectory' in 'where clause' - Invalid query: SELECT *
FROM `t_pasien`
WHERE MONTH(t_directory.tgldirectory) = 1
AND YEAR(t_directory.tgldirectory) = '2020'
AND `t_pasien`.`jeniskelamin` = 'L'
ORDER BY `t_pasien`.`modified` DESC
ERROR - 2020-02-20 07:26:58 --> Query error: Unknown column 't_directory.tgldirectory' in 'where clause' - Invalid query: SELECT *
FROM `t_pasien`
WHERE MONTH(t_directory.tgldirectory) = 1
AND YEAR(t_directory.tgldirectory) = '2020'
AND `t_pasien`.`jeniskelamin` = 'L'
ORDER BY `t_pasien`.`modified` DESC
ERROR - 2020-02-20 08:29:11 --> Severity: Error --> Maximum execution time of 30 seconds exceeded D:\webserver@raka\htdocs\rekam_medis\system\database\drivers\mysqli\mysqli_driver.php 305
ERROR - 2020-02-20 08:29:12 --> Severity: Error --> Maximum execution time of 30 seconds exceeded D:\webserver@raka\htdocs\rekam_medis\system\database\drivers\mysqli\mysqli_driver.php 305
ERROR - 2020-02-20 21:42:38 --> Query error: Unknown column 't_berkas.namalengkap' in 'where clause' - Invalid query: SELECT *
FROM `t_berkas`
LEFT JOIN `t_acs_nm` as `b` ON `t_berkas`.`iduserlevel` = `b`.`id`
WHERE `t_berkas`.`namalengkap` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`email` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `t_berkas`.`modified` DESC
 LIMIT 10
ERROR - 2020-02-20 21:43:18 --> Query error: Unknown column 't_berkas.namalengkap' in 'where clause' - Invalid query: SELECT *
FROM `t_berkas`
LEFT JOIN `t_acs_nm` as `b` ON `t_berkas`.`iduserlevel` = `b`.`id`
WHERE `t_berkas`.`namalengkap` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`email` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `t_berkas`.`modified` DESC
 LIMIT 10
ERROR - 2020-02-20 21:46:16 --> Query error: Unknown column 't_berkas.namalengkap' in 'where clause' - Invalid query: SELECT *
FROM `t_berkas`
LEFT JOIN `t_acs_nm` as `b` ON `t_berkas`.`iduserlevel` = `b`.`id`
WHERE `t_berkas`.`namalengkap` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`email` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `t_berkas`.`modified` DESC
 LIMIT 10
ERROR - 2020-02-20 22:17:01 --> Query error: Unknown column 't_berkas.namalengkap' in 'where clause' - Invalid query: SELECT *
FROM `t_berkas`
LEFT JOIN `t_acs_nm` as `b` ON `t_berkas`.`iduserlevel` = `b`.`id`
WHERE `t_berkas`.`namalengkap` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`email` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `t_berkas`.`modified` DESC
 LIMIT 10
ERROR - 2020-02-20 22:19:31 --> Query error: Unknown column 't_berkas.namalengkap' in 'where clause' - Invalid query: SELECT *
FROM `t_berkas`
LEFT JOIN `t_acs_nm` as `b` ON `t_berkas`.`iduserlevel` = `b`.`id`
WHERE `t_berkas`.`namalengkap` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`email` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `t_berkas`.`modified` DESC
 LIMIT 10
ERROR - 2020-02-20 22:19:36 --> Query error: Unknown column 't_berkas.namalengkap' in 'where clause' - Invalid query: SELECT *
FROM `t_berkas`
LEFT JOIN `t_acs_nm` as `b` ON `t_berkas`.`iduserlevel` = `b`.`id`
WHERE `t_berkas`.`namalengkap` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`email` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `t_berkas`.`modified` DESC
 LIMIT 10
ERROR - 2020-02-20 22:21:18 --> Query error: Unknown column 't_berkas.namalengkap' in 'where clause' - Invalid query: SELECT *
FROM `t_berkas`
LEFT JOIN `t_acs_nm` as `b` ON `t_berkas`.`iduserlevel` = `b`.`id`
WHERE `t_berkas`.`namalengkap` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`email` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `t_berkas`.`modified` DESC
 LIMIT 10
ERROR - 2020-02-20 22:21:57 --> Query error: Unknown column 't_berkas.namalengkap' in 'where clause' - Invalid query: SELECT *
FROM `t_berkas`
LEFT JOIN `t_acs_nm` as `b` ON `t_berkas`.`iduserlevel` = `b`.`id`
WHERE `t_berkas`.`namalengkap` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`email` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `t_berkas`.`modified` DESC
 LIMIT 10
ERROR - 2020-02-20 22:22:42 --> Query error: Unknown column 't_berkas.namalengkap' in 'where clause' - Invalid query: SELECT *
FROM `t_berkas`
LEFT JOIN `t_acs_nm` as `b` ON `t_berkas`.`iduserlevel` = `b`.`id`
WHERE `t_berkas`.`namalengkap` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`email` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `t_berkas`.`modified` DESC
 LIMIT 10
ERROR - 2020-02-20 22:22:55 --> Query error: Unknown column 't_berkas.namalengkap' in 'where clause' - Invalid query: SELECT *
FROM `t_berkas`
LEFT JOIN `t_acs_nm` as `b` ON `t_berkas`.`iduserlevel` = `b`.`id`
WHERE `t_berkas`.`namalengkap` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`email` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `t_berkas`.`modified` DESC
 LIMIT 10
ERROR - 2020-02-20 22:23:01 --> Query error: Unknown column 't_berkas.namalengkap' in 'where clause' - Invalid query: SELECT *
FROM `t_berkas`
LEFT JOIN `t_acs_nm` as `b` ON `t_berkas`.`iduserlevel` = `b`.`id`
WHERE `t_berkas`.`namalengkap` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`email` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `t_berkas`.`modified` DESC
 LIMIT 10
ERROR - 2020-02-20 22:25:18 --> Query error: Unknown column 't_berkas.namalengkap' in 'where clause' - Invalid query: SELECT *
FROM `t_berkas`
LEFT JOIN `t_acs_nm` as `b` ON `t_berkas`.`iduserlevel` = `b`.`id`
WHERE `t_berkas`.`namalengkap` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`email` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `t_berkas`.`modified` DESC
 LIMIT 10
ERROR - 2020-02-20 22:27:40 --> Query error: Unknown column 't_berkas.namalengkap' in 'where clause' - Invalid query: SELECT *
FROM `t_berkas`
LEFT JOIN `t_acs_nm` as `b` ON `t_berkas`.`iduserlevel` = `b`.`id`
WHERE `t_berkas`.`namalengkap` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`email` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `t_berkas`.`modified` DESC
 LIMIT 10
ERROR - 2020-02-20 22:34:09 --> Query error: Unknown column 't_berkas.namalengkap' in 'where clause' - Invalid query: SELECT *
FROM `t_berkas`
LEFT JOIN `t_acs_nm` as `b` ON `t_berkas`.`iduserlevel` = `b`.`id`
WHERE `t_berkas`.`namalengkap` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`email` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `t_berkas`.`modified` DESC
 LIMIT 10
ERROR - 2020-02-20 23:03:04 --> Query error: Unknown column 't_berkas.namalengkap' in 'where clause' - Invalid query: SELECT *
FROM `t_berkas`
LEFT JOIN `t_acs_nm` as `b` ON `t_berkas`.`iduserlevel` = `b`.`id`
WHERE `t_berkas`.`namalengkap` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`email` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `t_berkas`.`modified` DESC
 LIMIT 10
ERROR - 2020-02-20 23:03:39 --> Query error: Unknown column 't_berkas.namalengkap' in 'where clause' - Invalid query: SELECT *
FROM `t_berkas`
LEFT JOIN `t_acs_nm` as `b` ON `t_berkas`.`iduserlevel` = `b`.`id`
WHERE `t_berkas`.`namalengkap` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`email` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `t_berkas`.`modified` DESC
 LIMIT 10
ERROR - 2020-02-20 23:04:50 --> Query error: Unknown column 't_berkas.namalengkap' in 'where clause' - Invalid query: SELECT *
FROM `t_berkas`
LEFT JOIN `t_acs_nm` as `b` ON `t_berkas`.`iduserlevel` = `b`.`id`
WHERE `t_berkas`.`namalengkap` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`email` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `t_berkas`.`modified` DESC
 LIMIT 10
ERROR - 2020-02-20 23:05:36 --> Query error: Unknown column 't_berkas.namalengkap' in 'where clause' - Invalid query: SELECT *
FROM `t_berkas`
LEFT JOIN `t_acs_nm` as `b` ON `t_berkas`.`iduserlevel` = `b`.`id`
WHERE `t_berkas`.`namalengkap` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`email` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `t_berkas`.`modified` DESC
 LIMIT 10
ERROR - 2020-02-20 23:05:52 --> Query error: Unknown column 't_berkas.namalengkap' in 'where clause' - Invalid query: SELECT *
FROM `t_berkas`
LEFT JOIN `t_acs_nm` as `b` ON `t_berkas`.`iduserlevel` = `b`.`id`
WHERE `t_berkas`.`namalengkap` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`email` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `t_berkas`.`modified` DESC
 LIMIT 10
ERROR - 2020-02-20 23:07:19 --> Query error: Unknown column 't_berkas.namalengkap' in 'where clause' - Invalid query: SELECT *
FROM `t_berkas`
LEFT JOIN `t_acs_nm` as `b` ON `t_berkas`.`iduserlevel` = `b`.`id`
WHERE `t_berkas`.`namalengkap` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`email` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `t_berkas`.`modified` DESC
 LIMIT 10
ERROR - 2020-02-20 23:09:39 --> Query error: Unknown column 't_berkas.namalengkap' in 'where clause' - Invalid query: SELECT *
FROM `t_berkas`
LEFT JOIN `t_acs_nm` as `b` ON `t_berkas`.`iduserlevel` = `b`.`id`
WHERE `t_berkas`.`namalengkap` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`email` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `t_berkas`.`modified` DESC
 LIMIT 10
ERROR - 2020-02-20 23:11:38 --> Query error: Unknown column 't_berkas.namalengkap' in 'where clause' - Invalid query: SELECT *
FROM `t_berkas`
LEFT JOIN `t_acs_nm` as `b` ON `t_berkas`.`iduserlevel` = `b`.`id`
WHERE `t_berkas`.`namalengkap` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`email` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `t_berkas`.`modified` DESC
 LIMIT 10
ERROR - 2020-02-20 23:12:16 --> Query error: Unknown column 't_berkas.namalengkap' in 'where clause' - Invalid query: SELECT *
FROM `t_berkas`
LEFT JOIN `t_acs_nm` as `b` ON `t_berkas`.`iduserlevel` = `b`.`id`
WHERE `t_berkas`.`namalengkap` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`email` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `t_berkas`.`modified` DESC
 LIMIT 10
ERROR - 2020-02-20 23:14:59 --> Query error: Unknown column 't_berkas.namalengkap' in 'where clause' - Invalid query: SELECT *
FROM `t_berkas`
LEFT JOIN `t_acs_nm` as `b` ON `t_berkas`.`iduserlevel` = `b`.`id`
WHERE `t_berkas`.`namalengkap` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`email` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `t_berkas`.`modified` DESC
 LIMIT 10
ERROR - 2020-02-20 23:15:16 --> Query error: Unknown column 't_berkas.namalengkap' in 'where clause' - Invalid query: SELECT *
FROM `t_berkas`
LEFT JOIN `t_acs_nm` as `b` ON `t_berkas`.`iduserlevel` = `b`.`id`
WHERE `t_berkas`.`namalengkap` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`email` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `t_berkas`.`modified` DESC
 LIMIT 10
ERROR - 2020-02-20 23:16:22 --> Query error: Unknown column 't_berkas.namalengkap' in 'where clause' - Invalid query: SELECT *
FROM `t_berkas`
LEFT JOIN `t_acs_nm` as `b` ON `t_berkas`.`iduserlevel` = `b`.`id`
WHERE `t_berkas`.`namalengkap` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`email` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `t_berkas`.`modified` DESC
 LIMIT 10
ERROR - 2020-02-20 23:17:18 --> Query error: Unknown column 't_berkas.namalengkap' in 'where clause' - Invalid query: SELECT *
FROM `t_berkas`
LEFT JOIN `t_acs_nm` as `b` ON `t_berkas`.`iduserlevel` = `b`.`id`
WHERE `t_berkas`.`namalengkap` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`email` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `t_berkas`.`modified` DESC
 LIMIT 10
ERROR - 2020-02-20 23:25:56 --> Query error: Unknown column 't_berkas.namalengkap' in 'where clause' - Invalid query: SELECT *
FROM `t_berkas`
LEFT JOIN `t_acs_nm` as `b` ON `t_berkas`.`iduserlevel` = `b`.`id`
WHERE `t_berkas`.`namalengkap` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`email` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `t_berkas`.`modified` DESC
 LIMIT 10
ERROR - 2020-02-20 23:27:22 --> Query error: Unknown column 't_berkas.namalengkap' in 'where clause' - Invalid query: SELECT *
FROM `t_berkas`
LEFT JOIN `t_acs_nm` as `b` ON `t_berkas`.`iduserlevel` = `b`.`id`
WHERE `t_berkas`.`namalengkap` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`email` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `t_berkas`.`modified` DESC
 LIMIT 10
ERROR - 2020-02-20 23:30:50 --> Query error: Unknown column 't_berkas.namalengkap' in 'where clause' - Invalid query: SELECT *
FROM `t_berkas`
LEFT JOIN `t_acs_nm` as `b` ON `t_berkas`.`iduserlevel` = `b`.`id`
WHERE `t_berkas`.`namalengkap` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`email` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `t_berkas`.`modified` DESC
 LIMIT 10
ERROR - 2020-02-20 23:31:14 --> Query error: Unknown column 't_berkas.namalengkap' in 'where clause' - Invalid query: SELECT *
FROM `t_berkas`
LEFT JOIN `t_acs_nm` as `b` ON `t_berkas`.`iduserlevel` = `b`.`id`
WHERE `t_berkas`.`namalengkap` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`email` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `t_berkas`.`modified` DESC
 LIMIT 10
ERROR - 2020-02-20 23:32:16 --> Query error: Unknown column 't_berkas.namalengkap' in 'where clause' - Invalid query: SELECT *
FROM `t_berkas`
LEFT JOIN `t_acs_nm` as `b` ON `t_berkas`.`iduserlevel` = `b`.`id`
WHERE `t_berkas`.`namalengkap` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`email` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `t_berkas`.`modified` DESC
 LIMIT 10
ERROR - 2020-02-20 23:32:28 --> Query error: Unknown column 't_berkas.namalengkap' in 'where clause' - Invalid query: SELECT *
FROM `t_berkas`
LEFT JOIN `t_acs_nm` as `b` ON `t_berkas`.`iduserlevel` = `b`.`id`
WHERE `t_berkas`.`namalengkap` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`email` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `t_berkas`.`modified` DESC
 LIMIT 10
ERROR - 2020-02-20 23:32:52 --> Query error: Unknown column 't_berkas.namalengkap' in 'where clause' - Invalid query: SELECT *
FROM `t_berkas`
LEFT JOIN `t_acs_nm` as `b` ON `t_berkas`.`iduserlevel` = `b`.`id`
WHERE `t_berkas`.`namalengkap` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`email` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `t_berkas`.`modified` DESC
 LIMIT 10
ERROR - 2020-02-20 23:33:39 --> Query error: Unknown column 't_berkas.namalengkap' in 'where clause' - Invalid query: SELECT *
FROM `t_berkas`
LEFT JOIN `t_acs_nm` as `b` ON `t_berkas`.`iduserlevel` = `b`.`id`
WHERE `t_berkas`.`namalengkap` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`email` LIKE '%%' ESCAPE '!'
OR  `t_berkas`.`namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `t_berkas`.`modified` DESC
 LIMIT 10
