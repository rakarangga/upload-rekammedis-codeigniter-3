<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-03 00:14:53 --> Unable to connect to the database
ERROR - 2020-03-03 00:53:25 --> Severity: error --> Exception: Call to undefined method Fileupload::upload_handle() D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Berkas.php 80
ERROR - 2020-03-03 00:54:40 --> Severity: error --> Exception: Call to undefined method Fileupload::upload_handle() D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Berkas.php 80
ERROR - 2020-03-03 00:57:08 --> Severity: error --> Exception: Call to undefined method Fileupload::upload_handle() D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Berkas.php 80
ERROR - 2020-03-03 00:59:19 --> Severity: error --> Exception: Call to undefined method Fileupload::upload_handle() D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Berkas.php 80
ERROR - 2020-03-03 01:00:01 --> Severity: error --> Exception: Call to undefined method Fileupload::upload_handle() D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Berkas.php 80
ERROR - 2020-03-03 01:10:02 --> Severity: error --> Exception: Call to undefined method Fileupload::upload_handle() D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Berkas.php 80
ERROR - 2020-03-03 01:10:30 --> Severity: error --> Exception: Call to undefined method Fileupload::upload_handle() D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Berkas.php 80
ERROR - 2020-03-03 01:11:21 --> Severity: error --> Exception: Call to undefined method Fileupload::upload_handle() D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Berkas.php 80
ERROR - 2020-03-03 01:14:24 --> Severity: error --> Exception: Call to undefined method Fileupload::upload_handle() D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Berkas.php 80
ERROR - 2020-03-03 01:15:49 --> Could not find the language line "Server error. file direktori tidak tersedia."
ERROR - 2020-03-03 01:15:49 --> Server error. file direktori tidak tersedia.
ERROR - 2020-03-03 01:16:33 --> Could not find the language line "Server error. file direktori tidak tersedia."
ERROR - 2020-03-03 01:16:33 --> Server error. file direktori tidak tersedia.
ERROR - 2020-03-03 01:17:27 --> Could not find the language line "Server error. file direktori tidak tersedia."
ERROR - 2020-03-03 01:17:27 --> Server error. file direktori tidak tersedia.
ERROR - 2020-03-03 01:18:01 --> Could not find the language line "Server error. file direktori tidak tersedia."
ERROR - 2020-03-03 01:18:01 --> Server error. file direktori tidak tersedia.
ERROR - 2020-03-03 01:19:09 --> Could not find the language line "Server error. file direktori tidak tersedia."
ERROR - 2020-03-03 01:19:09 --> Server error. file direktori tidak tersedia.
ERROR - 2020-03-03 01:20:00 --> Could not find the language line "Server error. file direktori  tidak tersedia."
ERROR - 2020-03-03 01:20:00 --> Server error. file direktori  tidak tersedia.
ERROR - 2020-03-03 01:20:12 --> Could not find the language line "Server error. file direktori  tidak tersedia."
ERROR - 2020-03-03 01:20:12 --> Server error. file direktori  tidak tersedia.
ERROR - 2020-03-03 01:20:50 --> Could not find the language line "Server error. file direktori  tidak tersedia."
ERROR - 2020-03-03 01:20:50 --> Server error. file direktori  tidak tersedia.
ERROR - 2020-03-03 01:21:17 --> Could not find the language line "Server error. file direktori  tidak tersedia."
ERROR - 2020-03-03 01:21:17 --> Server error. file direktori  tidak tersedia.
ERROR - 2020-03-03 01:22:04 --> Could not find the language line "Server error. file direktori  tidak tersedia."
ERROR - 2020-03-03 01:22:04 --> Server error. file direktori  tidak tersedia.
ERROR - 2020-03-03 01:22:50 --> Could not find the language line "Server error. file direktori  tidak tersedia."
ERROR - 2020-03-03 01:22:50 --> Server error. file direktori  tidak tersedia.
ERROR - 2020-03-03 01:23:52 --> Could not find the language line "Server error. file direktori  tidak tersedia."
ERROR - 2020-03-03 01:23:52 --> Server error. file direktori  tidak tersedia.
ERROR - 2020-03-03 01:24:14 --> Could not find the language line "Server error. file direktori  tidak tersedia."
ERROR - 2020-03-03 01:24:14 --> Server error. file direktori  tidak tersedia.
ERROR - 2020-03-03 01:25:01 --> Could not find the language line "Server error. file direktori  tidak tersedia."
ERROR - 2020-03-03 01:25:01 --> Server error. file direktori  tidak tersedia.
ERROR - 2020-03-03 01:25:01 --> Could not find the language line "Server error. file direktori  tidak tersedia."
ERROR - 2020-03-03 01:25:01 --> Server error. file direktori  tidak tersedia.
ERROR - 2020-03-03 01:26:11 --> Could not find the language line "Server error. file direktori  tidak tersedia."
ERROR - 2020-03-03 01:26:11 --> Server error. file direktori  tidak tersedia.
ERROR - 2020-03-03 01:26:11 --> Severity: error --> Exception: Call to undefined method Fileupload::save_path() D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Berkas.php 85
ERROR - 2020-03-03 01:27:31 --> Could not find the language line "Server error. file direktori  tidak tersedia."
ERROR - 2020-03-03 01:27:31 --> Server error. file direktori  tidak tersedia.
ERROR - 2020-03-03 01:28:10 --> Could not find the language line "Server error. file direktori  tidak tersedia."
ERROR - 2020-03-03 01:28:10 --> Server error. file direktori  tidak tersedia.
ERROR - 2020-03-03 01:29:04 --> Could not find the language line "Server error. file direktori  tidak tersedia."
ERROR - 2020-03-03 01:29:04 --> Server error. file direktori  tidak tersedia.
ERROR - 2020-03-03 01:29:59 --> Could not find the language line "Server error. file direktori  tidak tersedia."
ERROR - 2020-03-03 01:29:59 --> Server error. file direktori  tidak tersedia.
ERROR - 2020-03-03 01:30:19 --> Could not find the language line "Server error. file direktori  tidak tersedia."
ERROR - 2020-03-03 01:30:19 --> Server error. file direktori  tidak tersedia.
ERROR - 2020-03-03 01:30:55 --> Severity: error --> Exception: Cannot access empty property D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Berkas.php 80
ERROR - 2020-03-03 01:31:12 --> Could not find the language line "Server error. file direktori  tidak tersedia."
ERROR - 2020-03-03 01:31:12 --> Server error. file direktori  tidak tersedia.
ERROR - 2020-03-03 01:39:11 --> Could not find the language line "Size File tidak valid"
ERROR - 2020-03-03 01:39:11 --> Size File tidak valid
ERROR - 2020-03-03 01:39:22 --> Could not find the language line "Server error. file direktori  tidak tersedia."
ERROR - 2020-03-03 01:39:22 --> Server error. file direktori  tidak tersedia.
ERROR - 2020-03-03 01:40:01 --> Could not find the language line "Size File tidak valid"
ERROR - 2020-03-03 01:40:01 --> Size File tidak valid
ERROR - 2020-03-03 01:40:19 --> Could not find the language line "Size File tidak valid"
ERROR - 2020-03-03 01:40:19 --> Size File tidak valid
ERROR - 2020-03-03 01:40:45 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-03 01:40:45 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-03 01:41:15 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-03 01:41:15 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-03 01:41:55 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-03 01:41:55 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-03 01:41:55 --> Severity: error --> Exception: Call to undefined method Fileupload::allowed_mime_type_arr() D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Berkas.php 83
ERROR - 2020-03-03 01:42:06 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-03 01:42:06 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-03 01:42:26 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-03 01:42:26 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-03 01:44:59 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-03 01:44:59 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-03 01:44:59 --> Severity: error --> Exception: Call to private method Fileupload::__checkMime() from context 'Berkas' D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Berkas.php 83
ERROR - 2020-03-03 01:45:26 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-03 01:45:26 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-03 01:46:24 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-03 01:46:24 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-03 01:47:16 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-03 01:47:16 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-03 01:47:46 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-03 01:47:46 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-03 01:48:03 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-03 01:48:03 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-03 01:49:20 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-03 01:49:20 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-03 01:49:25 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-03 01:49:25 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-03 01:49:43 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-03 01:49:43 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-03 01:51:13 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-03 01:51:13 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-03 01:53:22 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-03 01:53:22 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-03 01:54:23 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-03 01:54:23 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-03 01:55:20 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-03 01:55:20 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-03 01:55:38 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-03 01:55:38 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-03 01:57:04 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-03 01:57:04 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-03 01:57:27 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-03 01:57:27 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-03 01:58:11 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-03 01:58:11 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-03 01:59:02 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-03 01:59:02 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-03 01:59:15 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-03 01:59:15 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-03 02:01:16 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-03 02:01:16 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-03 02:14:09 --> Severity: error --> Exception: syntax error, unexpected '}' D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Berkas.php 91
ERROR - 2020-03-03 02:16:44 --> Severity: error --> Exception: Call to private method Fileupload::__allowed_types() from context 'Berkas' D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Berkas.php 92
ERROR - 2020-03-03 02:17:00 --> Severity: error --> Exception: Call to private method Fileupload::__allowed_types() from context 'Berkas' D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Berkas.php 92
ERROR - 2020-03-03 03:08:24 --> Could not find the language line "Size File tidak valid"
ERROR - 2020-03-03 03:08:24 --> Size File tidak valid
ERROR - 2020-03-03 03:11:41 --> Could not find the language line "Kapasitas File tidak boleh melebih 1024 kb"
ERROR - 2020-03-03 03:11:41 --> Kapasitas File tidak boleh melebih 1024 kb
ERROR - 2020-03-03 03:12:07 --> Could not find the language line "Kapasitas File tidak boleh melebih 1024 kb"
ERROR - 2020-03-03 03:12:07 --> Kapasitas File tidak boleh melebih 1024 kb
ERROR - 2020-03-03 03:19:31 --> Could not find the language line "Kapasitas File tidak boleh melebih 1024 kb"
ERROR - 2020-03-03 03:19:31 --> Kapasitas File tidak boleh melebih 1024 kb
ERROR - 2020-03-03 03:22:06 --> Could not find the language line "Kapasitas File tidak boleh melebih 1024 kb"
ERROR - 2020-03-03 03:22:06 --> Kapasitas File tidak boleh melebih 1024 kb
ERROR - 2020-03-03 03:23:29 --> Could not find the language line "Kapasitas File tidak boleh melebih 1024 kb"
ERROR - 2020-03-03 03:23:29 --> Kapasitas File tidak boleh melebih 1024 kb
ERROR - 2020-03-03 03:24:30 --> Could not find the language line "Kapasitas File tidak boleh melebih 1024 kb"
ERROR - 2020-03-03 03:24:30 --> Kapasitas File tidak boleh melebih 1024 kb
ERROR - 2020-03-03 03:25:02 --> Could not find the language line "Kapasitas File tidak boleh melebih 1024 kb"
ERROR - 2020-03-03 03:25:02 --> Kapasitas File tidak boleh melebih 1024 kb
ERROR - 2020-03-03 03:25:24 --> Could not find the language line "Kapasitas File tidak boleh melebih 1024 kb"
ERROR - 2020-03-03 03:25:24 --> Kapasitas File tidak boleh melebih 1024 kb
ERROR - 2020-03-03 03:26:10 --> Could not find the language line "Kapasitas File tidak boleh melebih 1024 kb"
ERROR - 2020-03-03 03:26:10 --> Kapasitas File tidak boleh melebih 1024 kb
ERROR - 2020-03-03 03:31:11 --> Could not find the language line "Kapasitas File tidak boleh melebih 1024 kb"
ERROR - 2020-03-03 03:31:11 --> Kapasitas File tidak boleh melebih 1024 kb
ERROR - 2020-03-03 03:31:31 --> Could not find the language line "Kapasitas File tidak boleh melebih 1024 kb"
ERROR - 2020-03-03 03:31:31 --> Kapasitas File tidak boleh melebih 1024 kb
ERROR - 2020-03-03 03:32:13 --> Could not find the language line "Kapasitas File tidak boleh melebih 1024 kb"
ERROR - 2020-03-03 03:32:13 --> Kapasitas File tidak boleh melebih 1024 kb
ERROR - 2020-03-03 03:37:11 --> Could not find the language line "Kapasitas File tidak boleh melebih 1024 kb"
ERROR - 2020-03-03 03:37:11 --> Kapasitas File tidak boleh melebih 1024 kb
ERROR - 2020-03-03 03:37:14 --> Could not find the language line "Kapasitas File tidak boleh melebih 1024 kb"
ERROR - 2020-03-03 03:37:14 --> Kapasitas File tidak boleh melebih 1024 kb
ERROR - 2020-03-03 03:37:15 --> Could not find the language line "Kapasitas File tidak boleh melebih 1024 kb"
ERROR - 2020-03-03 03:37:15 --> Kapasitas File tidak boleh melebih 1024 kb
ERROR - 2020-03-03 03:37:15 --> Could not find the language line "Kapasitas File tidak boleh melebih 1024 kb"
ERROR - 2020-03-03 03:37:15 --> Kapasitas File tidak boleh melebih 1024 kb
ERROR - 2020-03-03 03:37:25 --> Could not find the language line "Kapasitas File tidak boleh melebih 1024 kb"
ERROR - 2020-03-03 03:37:25 --> Kapasitas File tidak boleh melebih 1024 kb
ERROR - 2020-03-03 03:37:33 --> Could not find the language line "Kapasitas File tidak boleh melebih 1024 kb"
ERROR - 2020-03-03 03:37:33 --> Kapasitas File tidak boleh melebih 1024 kb
ERROR - 2020-03-03 03:39:52 --> Could not find the language line "Kapasitas File tidak boleh melebih 1024 kb"
ERROR - 2020-03-03 03:39:52 --> Kapasitas File tidak boleh melebih 1024 kb
ERROR - 2020-03-03 03:40:40 --> Could not find the language line "Kapasitas File tidak boleh melebih 1024 kb"
ERROR - 2020-03-03 03:40:40 --> Kapasitas File tidak boleh melebih 1024 kb
ERROR - 2020-03-03 03:41:19 --> Could not find the language line "Kapasitas File tidak boleh melebih 1024 kb"
ERROR - 2020-03-03 03:41:19 --> Kapasitas File tidak boleh melebih 1024 kb
ERROR - 2020-03-03 03:41:39 --> Could not find the language line "Kapasitas File tidak boleh melebih 1024 kb"
ERROR - 2020-03-03 03:41:39 --> Kapasitas File tidak boleh melebih 1024 kb
ERROR - 2020-03-03 03:55:22 --> Could not find the language line "Kapasitas File tidak boleh melebih 1024 kb"
ERROR - 2020-03-03 03:55:22 --> Kapasitas File tidak boleh melebih 1024 kb
ERROR - 2020-03-03 19:47:28 --> Query error: Unknown column 'namadirectory' in 'order clause' - Invalid query: SELECT *
FROM `t_pasien`
WHERE `iddirectory` = '1'
AND `id_user` = '6'
ORDER BY `t_pasien`.`modified` DESC, `namadirectory` ASC
 LIMIT 10
ERROR - 2020-03-03 19:49:57 --> Query error: Unknown column 'namadirectory' in 'order clause' - Invalid query: SELECT *
FROM `t_pasien`
WHERE `iddirectory` = '1'
AND `id_user` = '6'
ORDER BY `t_pasien`.`modified` DESC, `namadirectory` ASC
 LIMIT 10
ERROR - 2020-03-03 19:50:44 --> Query error: Unknown column 'namadirectory' in 'order clause' - Invalid query: SELECT *
FROM `t_pasien`
WHERE `iddirectory` = '1'
AND `id_user` = '6'
ORDER BY `t_pasien`.`modified` DESC, `namadirectory` ASC
 LIMIT 10
ERROR - 2020-03-03 19:50:47 --> Query error: Unknown column 'namadirectory' in 'order clause' - Invalid query: SELECT *
FROM `t_pasien`
WHERE `iddirectory` = '1'
AND `id_user` = '6'
ORDER BY `t_pasien`.`modified` DESC, `namadirectory` DESC
 LIMIT 10
ERROR - 2020-03-03 19:53:17 --> Query error: Unknown column 'No.RM' in 'order clause' - Invalid query: SELECT *
FROM `t_pasien`
WHERE `iddirectory` = '1'
AND `id_user` = '6'
ORDER BY `t_pasien`.`modified` DESC, `No`. `RM` ASC
 LIMIT 10
ERROR - 2020-03-03 19:53:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`Pasien` ASC
 LIMIT 10' at line 5 - Invalid query: SELECT *
FROM `t_pasien`
WHERE `iddirectory` = '1'
AND `id_user` = '6'
ORDER BY `t_pasien`.`modified` DESC, `Nama` `Pasien` ASC
 LIMIT 10
ERROR - 2020-03-03 19:53:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`Kelamin` ASC
 LIMIT 10' at line 5 - Invalid query: SELECT *
FROM `t_pasien`
WHERE `iddirectory` = '1'
AND `id_user` = '6'
ORDER BY `t_pasien`.`modified` DESC, `Jenis` `Kelamin` ASC
 LIMIT 10
ERROR - 2020-03-03 20:09:48 --> Query error: Unknown column 'namadirectory' in 'order clause' - Invalid query: SELECT *
FROM `t_pasien`
WHERE `iddirectory` = '1'
AND `id_user` = '6'
ORDER BY `namadirectory` ASC
 LIMIT 10
ERROR - 2020-03-03 20:09:59 --> Query error: Unknown column 'namadirectory' in 'order clause' - Invalid query: SELECT *
FROM `t_pasien`
WHERE `iddirectory` = '1'
AND `id_user` = '6'
ORDER BY `namadirectory` ASC
 LIMIT 10
ERROR - 2020-03-03 20:10:12 --> Query error: Unknown column 'namadirectory' in 'order clause' - Invalid query: SELECT *
FROM `t_pasien`
WHERE `iddirectory` = '1'
AND `id_user` = '6'
ORDER BY `namadirectory` ASC
 LIMIT 10
ERROR - 2020-03-03 20:10:33 --> Query error: Unknown column 'No.RM' in 'order clause' - Invalid query: SELECT *
FROM `t_pasien`
WHERE `iddirectory` = '1'
AND `id_user` = '6'
ORDER BY `No`. `RM` ASC
 LIMIT 10
ERROR - 2020-03-03 20:10:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`Pasien` ASC
 LIMIT 10' at line 5 - Invalid query: SELECT *
FROM `t_pasien`
WHERE `iddirectory` = '1'
AND `id_user` = '6'
ORDER BY `Nama` `Pasien` ASC
 LIMIT 10
ERROR - 2020-03-03 20:10:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`Kelamin` ASC
 LIMIT 10' at line 5 - Invalid query: SELECT *
FROM `t_pasien`
WHERE `iddirectory` = '1'
AND `id_user` = '6'
ORDER BY `Jenis` `Kelamin` ASC
 LIMIT 10
ERROR - 2020-03-03 20:10:39 --> Query error: Unknown column 'No.RM' in 'order clause' - Invalid query: SELECT *
FROM `t_pasien`
WHERE `iddirectory` = '1'
AND `id_user` = '6'
ORDER BY `No`. `RM` ASC
 LIMIT 10
ERROR - 2020-03-03 20:11:40 --> Query error: Unknown column 'namadirectory' in 'order clause' - Invalid query: SELECT *
FROM `t_pasien`
WHERE `iddirectory` = '1'
AND `id_user` = '6'
ORDER BY `namadirectory` ASC
 LIMIT 10
ERROR - 2020-03-03 20:22:46 --> Query error: Unknown column 'namadirectory' in 'order clause' - Invalid query: SELECT *
FROM `t_pasien`
WHERE `iddirectory` = '1'
AND `id_user` = '6'
ORDER BY `namadirectory` ASC
 LIMIT 10
ERROR - 2020-03-03 20:22:56 --> Query error: Unknown column 'namadirectory' in 'order clause' - Invalid query: SELECT *
FROM `t_pasien`
WHERE `iddirectory` = '1'
AND `id_user` = '6'
ORDER BY `namadirectory` ASC
 LIMIT 10
ERROR - 2020-03-03 20:26:16 --> Query error: Unknown column 'namadirectory' in 'order clause' - Invalid query: SELECT *
FROM `t_pasien`
WHERE `iddirectory` = '1'
AND `id_user` = '6'
ORDER BY `namadirectory` ASC
 LIMIT 10
ERROR - 2020-03-03 20:26:39 --> Query error: Unknown column 'namadirectory' in 'order clause' - Invalid query: SELECT *
FROM `t_pasien`
WHERE `iddirectory` = '1'
AND `id_user` = '6'
ORDER BY `namadirectory` ASC
 LIMIT 10
ERROR - 2020-03-03 20:27:08 --> Query error: Unknown column 'namadirectory' in 'order clause' - Invalid query: SELECT *
FROM `t_pasien`
WHERE `iddirectory` = '1'
AND `id_user` = '6'
ORDER BY `namadirectory` ASC
 LIMIT 10
ERROR - 2020-03-03 21:05:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'DESC
 LIMIT 10' at line 5 - Invalid query: SELECT *
FROM `t_pasien`
WHERE `iddirectory` = '1'
AND `id_user` = '6'
ORDER BY .`modified` DESC
 LIMIT 10
