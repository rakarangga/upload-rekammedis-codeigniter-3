<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-04 02:49:51 --> Could not find the language line "Server error. file direktori  tidak tersedia."
ERROR - 2020-03-04 02:49:51 --> Server error. file direktori  tidak tersedia.
ERROR - 2020-03-04 02:55:16 --> Could not find the language line "Server error. file direktori  tidak tersedia."
ERROR - 2020-03-04 02:55:16 --> Server error. file direktori  tidak tersedia.
ERROR - 2020-03-04 02:56:41 --> Could not find the language line "Server error. file direktori  tidak tersedia."
ERROR - 2020-03-04 02:56:41 --> Server error. file direktori  tidak tersedia.
ERROR - 2020-03-04 03:01:11 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-04 03:01:11 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-04 03:05:15 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-04 03:05:15 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-04 03:12:12 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-04 03:12:12 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-04 03:14:49 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-04 03:14:49 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-04 03:16:50 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-04 03:16:50 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-04 03:17:46 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-04 03:17:46 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-04 03:21:03 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-04 03:21:03 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-04 03:23:34 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-04 03:23:34 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-04 03:24:06 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-04 03:24:06 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-04 03:24:16 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-04 03:24:16 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-04 03:24:51 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-04 03:24:51 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-04 03:24:51 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-04 03:24:51 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-04 03:25:36 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-04 03:25:36 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-04 03:25:36 --> Severity: error --> Exception: Call to private method Fileupload::__checkMime() from context 'Berkas' D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Berkas.php 111
ERROR - 2020-03-04 03:25:54 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-04 03:25:54 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-04 03:27:18 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-04 03:27:18 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-04 03:28:24 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-04 03:28:24 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-04 03:28:54 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-04 03:28:54 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-04 03:29:22 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-04 03:29:22 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-04 03:30:56 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-04 03:30:56 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-04 03:31:22 --> Could not find the language line "File yang dipilih tidak diizinkan"
ERROR - 2020-03-04 03:31:22 --> File yang dipilih tidak diizinkan
ERROR - 2020-03-04 06:39:52 --> Could not find the language line "Kapasitas File tidak boleh melebih 512 kb"
ERROR - 2020-03-04 06:39:52 --> Kapasitas File tidak boleh melebih 512 kb
ERROR - 2020-03-04 06:40:19 --> Could not find the language line "Kapasitas File tidak boleh melebih 512 kb"
ERROR - 2020-03-04 06:40:19 --> Kapasitas File tidak boleh melebih 512 kb
ERROR - 2020-03-04 06:41:07 --> Could not find the language line "Kapasitas File tidak boleh melebih 512 kb"
ERROR - 2020-03-04 06:41:07 --> Kapasitas File tidak boleh melebih 512 kb
ERROR - 2020-03-04 06:42:00 --> Could not find the language line "Kapasitas File tidak boleh melebih 512 kb"
ERROR - 2020-03-04 06:42:00 --> Kapasitas File tidak boleh melebih 512 kb
ERROR - 2020-03-04 06:42:41 --> Could not find the language line "Kapasitas File tidak boleh melebih 512 kb"
ERROR - 2020-03-04 06:42:41 --> Kapasitas File tidak boleh melebih 512 kb
