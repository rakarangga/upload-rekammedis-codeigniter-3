<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-24 15:53:49 --> Unable to connect to the database
ERROR - 2020-02-24 16:08:37 --> Unable to connect to the database
ERROR - 2020-02-24 16:14:12 --> Unable to connect to the database
