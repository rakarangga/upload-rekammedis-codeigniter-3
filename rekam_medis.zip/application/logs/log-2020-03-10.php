<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-10 01:24:49 --> Unable to connect to the database
ERROR - 2020-03-10 01:24:52 --> Unable to connect to the database
ERROR - 2020-03-10 01:27:15 --> Severity: error --> Exception: Call to undefined function inval() D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Dashboard.php 104
ERROR - 2020-03-10 01:36:39 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Pasien.php 121
ERROR - 2020-03-10 15:59:34 --> Query error: MySQL server has gone away - Invalid query: SELECT SUM(`stts`) AS `stts`
FROM `t_pasien`
WHERE `stts` = 1 AND (`created` BETWEEN DATE_ADD(CURDATE(), INTERVAL -1 day) AND CURDATE())
ORDER BY `t_pasien`.`modified` DESC
ERROR - 2020-03-10 15:59:34 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `t_berkas`
ORDER BY `t_berkas`.`modified` DESC
ERROR - 2020-03-10 15:59:34 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `t_pasien`
WHERE `stts` = 1
ORDER BY `t_pasien`.`modified` DESC
ERROR - 2020-03-10 15:59:34 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `t_berkas`
ORDER BY `t_berkas`.`modified` DESC
ERROR - 2020-03-10 15:59:34 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `t_pasien`
WHERE `stts` = 1
ORDER BY `t_pasien`.`modified` DESC
ERROR - 2020-03-10 15:59:34 --> Query error: MySQL server has gone away - Invalid query: SELECT SUM(`stts`) AS `stts`
FROM `t_pasien`
WHERE `stts` = 1 AND (`created` BETWEEN DATE_ADD(CURDATE(), INTERVAL -1 day) AND CURDATE())
ORDER BY `t_pasien`.`modified` DESC
ERROR - 2020-03-10 15:59:34 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `t_pasien`
WHERE `stts` = 1
ORDER BY `t_pasien`.`modified` DESC
ERROR - 2020-03-10 15:59:34 --> Query error: MySQL server has gone away - Invalid query: SELECT SUM(`stts`) AS `stts`
FROM `t_pasien`
WHERE `stts` = 1 AND (`created` BETWEEN DATE_ADD(CURDATE(), INTERVAL -1 day) AND CURDATE())
ORDER BY `t_pasien`.`modified` DESC
ERROR - 2020-03-10 15:59:34 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `t_berkas`
ORDER BY `t_berkas`.`modified` DESC
ERROR - 2020-03-10 15:59:34 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `t_pasien`
WHERE `stts` = 1
ORDER BY `t_pasien`.`modified` DESC
ERROR - 2020-03-10 15:59:34 --> Query error: MySQL server has gone away - Invalid query: SELECT SUM(`stts`) AS `stts`
FROM `t_pasien`
WHERE `stts` = 1 AND (`created` BETWEEN DATE_ADD(CURDATE(), INTERVAL -1 day) AND CURDATE())
ORDER BY `t_pasien`.`modified` DESC
ERROR - 2020-03-10 15:59:34 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `t_berkas`
ORDER BY `t_berkas`.`modified` DESC
