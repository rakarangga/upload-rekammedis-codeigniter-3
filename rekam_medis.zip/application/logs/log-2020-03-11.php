<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-11 17:28:51 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `t_berkas`
ORDER BY `t_berkas`.`modified` DESC
ERROR - 2020-03-11 17:28:51 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `t_pasien`
WHERE `stts` = 1
ORDER BY `t_pasien`.`modified` DESC
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-11 17:28:51 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `t_berkas`
ORDER BY `t_berkas`.`modified` DESC
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-11 17:28:51 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `t_pasien`
WHERE `stts` = 1
ORDER BY `t_pasien`.`modified` DESC
