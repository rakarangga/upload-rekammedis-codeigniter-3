<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-02 21:26:00 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ';' D:\webserver@raka\htdocs\__2020\rekam_medis\application\libraries\Fileupload.php 47
ERROR - 2020-03-02 21:26:16 --> Severity: error --> Exception: Call to undefined function __allowed_type() D:\webserver@raka\htdocs\__2020\rekam_medis\application\libraries\Fileupload.php 33
ERROR - 2020-03-02 22:54:59 --> Severity: error --> Exception: Call to undefined method Fileupload::upload_handle() D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Berkas.php 61
ERROR - 2020-03-02 23:02:46 --> Severity: error --> Exception: Call to undefined method Fileupload::upload_handle() D:\webserver@raka\htdocs\__2020\rekam_medis\application\controllers\backoffice\Berkas.php 61
