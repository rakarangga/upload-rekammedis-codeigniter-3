<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-25 16:37:21 --> Unable to connect to the database
ERROR - 2020-02-25 20:08:42 --> Severity: error --> Exception: Call to a member function set_template() on null D:\webserver@raka\htdocs\rekam_medis\application\libraries\DatatablesBuilder.php 170
ERROR - 2020-02-25 20:12:21 --> Query error: Unknown column 'name' in 'order clause' - Invalid query: SELECT *
FROM `t_directory`
ORDER BY `name` ASC
 LIMIT 10
ERROR - 2020-02-25 20:12:26 --> Query error: Unknown column 'name' in 'order clause' - Invalid query: SELECT *
FROM `t_directory`
ORDER BY `name` ASC
 LIMIT 10
ERROR - 2020-02-25 20:14:10 --> Query error: Unknown column 'name' in 'order clause' - Invalid query: SELECT *
FROM `t_directory`
ORDER BY `name` ASC
 LIMIT 10
ERROR - 2020-02-25 20:19:18 --> Query error: Unknown column 'name' in 'order clause' - Invalid query: SELECT *
FROM `t_directory`
ORDER BY `name` ASC
 LIMIT 10
ERROR - 2020-02-25 20:20:34 --> Query error: Unknown column 'name' in 'order clause' - Invalid query: SELECT *
FROM `t_directory`
ORDER BY `name` ASC
 LIMIT 10
ERROR - 2020-02-25 20:45:19 --> Query error: Unknown column 'aksi' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `t_directory`
WHERE `namadirectory` LIKE '%janu%' ESCAPE '!'
OR   `aksi` LIKE '%janu%' ESCAPE '!'
ERROR - 2020-02-25 20:49:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIKE '%2011%' ESCAPE '!'' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `t_directory`
WHERE  LIKE '%2011%' ESCAPE '!'
ERROR - 2020-02-25 20:56:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIKE '%2011%' ESCAPE '!'' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `t_directory`
WHERE  LIKE '%2011%' ESCAPE '!'
ERROR - 2020-02-25 21:02:23 --> Query error: Unknown column 'Aksi' in 'order clause' - Invalid query: SELECT *
FROM `t_directory`
ORDER BY `Aksi` ASC
 LIMIT 10
ERROR - 2020-02-25 21:02:26 --> Query error: Unknown column 'Aksi' in 'order clause' - Invalid query: SELECT *
FROM `t_directory`
ORDER BY `Aksi` DESC
 LIMIT 10
ERROR - 2020-02-25 21:04:47 --> Query error: Unknown column 'Aksi' in 'order clause' - Invalid query: SELECT *
FROM `t_directory`
ORDER BY `Aksi` DESC
 LIMIT 10, 10
ERROR - 2020-02-25 21:46:10 --> Query error: Unknown column 'Aksi' in 'order clause' - Invalid query: SELECT *
FROM `t_directory`
ORDER BY `Aksi` ASC
 LIMIT 10
ERROR - 2020-02-25 21:47:40 --> Query error: Unknown column 'Aksi' in 'order clause' - Invalid query: SELECT *
FROM `t_directory`
ORDER BY `Aksi` ASC
 LIMIT 10
ERROR - 2020-02-25 22:44:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`fa-folder"></span>` ASC
 LIMIT 10' at line 3 - Invalid query: SELECT *
FROM `t_directory`
ORDER BY `<span class="fa` `fa-folder"></span>` ASC
 LIMIT 10
ERROR - 2020-02-25 22:44:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`fa-folder"></span>` ASC
 LIMIT 10, 10' at line 3 - Invalid query: SELECT *
FROM `t_directory`
ORDER BY `<span class="fa` `fa-folder"></span>` ASC
 LIMIT 10, 10
ERROR - 2020-02-25 22:49:39 --> Query error: Unknown column 'Aksi' in 'order clause' - Invalid query: SELECT *
FROM `t_directory`
ORDER BY `Aksi` ASC
 LIMIT 10
