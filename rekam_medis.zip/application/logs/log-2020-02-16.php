<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-16 05:34:48 --> Query error: No tables used - Invalid query: SELECT *
ORDER BY `modified` DESC
 LIMIT 10
ERROR - 2020-02-16 05:35:07 --> Query error: No tables used - Invalid query: SELECT *
ORDER BY `modified` DESC
ERROR - 2020-02-16 05:37:27 --> Query error: No tables used - Invalid query: SELECT *
ORDER BY `modified` DESC
ERROR - 2020-02-16 05:37:29 --> Query error: No tables used - Invalid query: SELECT *
ORDER BY `modified` DESC
ERROR - 2020-02-16 06:27:12 --> Query error: Unknown column 'an_name' in 'where clause' - Invalid query: SELECT *
FROM `logis_users`
WHERE `namalengkap` LIKE '%%' ESCAPE '!'
OR  `email` LIKE '%%' ESCAPE '!'
OR  `namauser` LIKE '%%' ESCAPE '!'
OR  `an_name` LIKE '%%' ESCAPE '!'
ORDER BY `modified` DESC
 LIMIT 10
ERROR - 2020-02-16 06:28:04 --> Query error: Unknown column 'an_name' in 'where clause' - Invalid query: SELECT *
FROM `logis_users`
WHERE `namalengkap` LIKE '%%' ESCAPE '!'
OR  `email` LIKE '%%' ESCAPE '!'
OR  `namauser` LIKE '%%' ESCAPE '!'
OR  `an_name` LIKE '%%' ESCAPE '!'
ORDER BY `modified` DESC
 LIMIT 10
ERROR - 2020-02-16 06:28:17 --> Query error: Unknown column 'an_name' in 'where clause' - Invalid query: SELECT *
FROM `logis_users`
WHERE `namalengkap` LIKE '%%' ESCAPE '!'
OR  `email` LIKE '%%' ESCAPE '!'
OR  `namauser` LIKE '%%' ESCAPE '!'
OR  `an_name` LIKE '%%' ESCAPE '!'
ORDER BY `modified` DESC
 LIMIT 10
ERROR - 2020-02-16 06:29:30 --> Query error: Unknown column 'b.an_name' in 'where clause' - Invalid query: SELECT *
FROM `logis_users`
WHERE `namalengkap` LIKE '%%' ESCAPE '!'
OR  `email` LIKE '%%' ESCAPE '!'
OR  `namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `modified` DESC
 LIMIT 10
ERROR - 2020-02-16 06:31:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LEFT JOIN `t_acs_nm` as `b` ON `logis_users`.`iduserlevel` = `b`.`id`
WHERE `nam' at line 2 - Invalid query: SELECT *
LEFT JOIN `t_acs_nm` as `b` ON `logis_users`.`iduserlevel` = `b`.`id`
WHERE `namalengkap` LIKE '%%' ESCAPE '!'
OR  `email` LIKE '%%' ESCAPE '!'
OR  `namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `modified` DESC
 LIMIT 10
ERROR - 2020-02-16 06:34:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LEFT JOIN `t_acs_nm` as `b` ON `logis_users`.`iduserlevel` = `b`.`id`
WHERE `nam' at line 2 - Invalid query: SELECT *
LEFT JOIN `t_acs_nm` as `b` ON `logis_users`.`iduserlevel` = `b`.`id`
WHERE `namalengkap` LIKE '%%' ESCAPE '!'
OR  `email` LIKE '%%' ESCAPE '!'
OR  `namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `modified` DESC
 LIMIT 10
ERROR - 2020-02-16 06:34:21 --> Query error: No tables used - Invalid query: SELECT *
 LIMIT 10
ERROR - 2020-02-16 06:40:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'WHERE `namalengkap` LIKE '%%' ESCAPE '!'
OR  `email` LIKE '%%' ESCAPE '!'
OR  `n' at line 2 - Invalid query: SELECT *
WHERE `namalengkap` LIKE '%%' ESCAPE '!'
OR  `email` LIKE '%%' ESCAPE '!'
OR  `namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `modified` DESC
ERROR - 2020-02-16 06:42:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LEFT JOIN `t_acs_nm` as `b` ON `logis_users`.`iduserlevel` = `b`.`id`
WHERE `nam' at line 2 - Invalid query: SELECT *
LEFT JOIN `t_acs_nm` as `b` ON `logis_users`.`iduserlevel` = `b`.`id`
WHERE `namalengkap` LIKE '%%' ESCAPE '!'
OR  `email` LIKE '%%' ESCAPE '!'
OR  `namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `modified` DESC
 LIMIT 10
ERROR - 2020-02-16 06:42:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'WHERE `namalengkap` LIKE '%%' ESCAPE '!'
OR  `email` LIKE '%%' ESCAPE '!'
OR  `n' at line 2 - Invalid query: SELECT *
WHERE `namalengkap` LIKE '%%' ESCAPE '!'
OR  `email` LIKE '%%' ESCAPE '!'
OR  `namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `modified` DESC
ERROR - 2020-02-16 06:43:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'WHERE `namalengkap` LIKE '%%' ESCAPE '!'
OR  `email` LIKE '%%' ESCAPE '!'
OR  `n' at line 2 - Invalid query: SELECT *
WHERE `namalengkap` LIKE '%%' ESCAPE '!'
OR  `email` LIKE '%%' ESCAPE '!'
OR  `namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `modified` DESC
ERROR - 2020-02-16 06:44:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*
FROM `logis_users`
LEFT JOIN `t_acs_nm` as `b` ON `logis_users`.`iduserlevel` ' at line 1 - Invalid query: SELECT *, *
FROM `logis_users`
LEFT JOIN `t_acs_nm` as `b` ON `logis_users`.`iduserlevel` = `b`.`id`
WHERE `namalengkap` LIKE '%%' ESCAPE '!'
OR  `email` LIKE '%%' ESCAPE '!'
OR  `namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `modified` DESC
ERROR - 2020-02-16 06:45:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'WHERE `namalengkap` LIKE '%%' ESCAPE '!'
OR  `email` LIKE '%%' ESCAPE '!'
OR  `n' at line 2 - Invalid query: SELECT *
WHERE `namalengkap` LIKE '%%' ESCAPE '!'
OR  `email` LIKE '%%' ESCAPE '!'
OR  `namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `modified` DESC
ERROR - 2020-02-16 06:46:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*
FROM `logis_users`
LEFT JOIN `t_acs_nm` as `b` ON `logis_users`.`iduserlevel` ' at line 1 - Invalid query: SELECT *, *
FROM `logis_users`
LEFT JOIN `t_acs_nm` as `b` ON `logis_users`.`iduserlevel` = `b`.`id`
WHERE `namalengkap` LIKE '%%' ESCAPE '!'
OR  `email` LIKE '%%' ESCAPE '!'
OR  `namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `modified` DESC
ERROR - 2020-02-16 06:46:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*
FROM `logis_users`
LEFT JOIN `t_acs_nm` as `b` ON `logis_users`.`iduserlevel` ' at line 1 - Invalid query: SELECT *, *
FROM `logis_users`
LEFT JOIN `t_acs_nm` as `b` ON `logis_users`.`iduserlevel` = `b`.`id`
ORDER BY `modified` DESC
ERROR - 2020-02-16 06:47:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*
FROM `logis_users`
LEFT JOIN `t_acs_nm` as `b` ON `logis_users`.`iduserlevel` ' at line 1 - Invalid query: SELECT `namalengkap`, `email`, `namauser`, *
FROM `logis_users`
LEFT JOIN `t_acs_nm` as `b` ON `logis_users`.`iduserlevel` = `b`.`id`
ORDER BY `modified` DESC
ERROR - 2020-02-16 06:47:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*
FROM (`logis_users`, `logis_users`)
LEFT JOIN `t_acs_nm` as `b` ON `logis_user' at line 1 - Invalid query: SELECT `namalengkap`, `email`, `namauser`, *
FROM (`logis_users`, `logis_users`)
LEFT JOIN `t_acs_nm` as `b` ON `logis_users`.`iduserlevel` = `b`.`id`
ORDER BY `modified` DESC
ERROR - 2020-02-16 06:48:37 --> Query error: No tables used - Invalid query: SELECT *
ORDER BY `modified` DESC
ERROR - 2020-02-16 06:48:42 --> Query error: No tables used - Invalid query: SELECT *
ORDER BY `modified` DESC
 LIMIT 10
ERROR - 2020-02-16 06:51:21 --> Query error: No tables used - Invalid query: SELECT *
ORDER BY `modified` DESC
ERROR - 2020-02-16 06:51:22 --> Query error: No tables used - Invalid query: SELECT *
ORDER BY `modified` DESC
ERROR - 2020-02-16 06:51:24 --> Query error: No tables used - Invalid query: SELECT *
ORDER BY `modified` DESC
 LIMIT 10
ERROR - 2020-02-16 06:52:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*
FROM (`logis_users`, `logis_users`)
LEFT JOIN `t_acs_nm` as `b` ON `logis_user' at line 1 - Invalid query: SELECT *, *
FROM (`logis_users`, `logis_users`)
LEFT JOIN `t_acs_nm` as `b` ON `logis_users`.`iduserlevel` = `b`.`id`
WHERE `namalengkap` LIKE '%%' ESCAPE '!'
OR  `email` LIKE '%%' ESCAPE '!'
OR  `namauser` LIKE '%%' ESCAPE '!'
OR  `an_name` LIKE '%%' ESCAPE '!'
ORDER BY `modified` DESC
ERROR - 2020-02-16 06:52:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*
FROM `logis_users`, `logis_users`
WHERE `namalengkap` LIKE '%%' ESCAPE '!'
OR ' at line 1 - Invalid query: SELECT *, *
FROM `logis_users`, `logis_users`
WHERE `namalengkap` LIKE '%%' ESCAPE '!'
OR  `email` LIKE '%%' ESCAPE '!'
OR  `namauser` LIKE '%%' ESCAPE '!'
OR  `an_name` LIKE '%%' ESCAPE '!'
ORDER BY `modified` DESC
ERROR - 2020-02-16 06:54:11 --> Query error: Not unique table/alias: 'logis_users' - Invalid query: SELECT *
FROM `logis_users`, `logis_users`
WHERE `namalengkap` LIKE '%%' ESCAPE '!'
OR  `email` LIKE '%%' ESCAPE '!'
OR  `namauser` LIKE '%%' ESCAPE '!'
OR  `an_name` LIKE '%%' ESCAPE '!'
ORDER BY `modified` DESC
ERROR - 2020-02-16 06:55:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*
FROM `logis_users`, `logis_users`
ORDER BY `modified` DESC' at line 1 - Invalid query: SELECT *, *
FROM `logis_users`, `logis_users`
ORDER BY `modified` DESC
ERROR - 2020-02-16 06:56:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*
FROM `logis_users`, `logis_users`
ORDER BY `modified` DESC' at line 1 - Invalid query: SELECT *, *
FROM `logis_users`, `logis_users`
ORDER BY `modified` DESC
ERROR - 2020-02-16 06:57:13 --> Query error: Unknown column 'an_name' in 'where clause' - Invalid query: SELECT *
FROM `logis_users`
WHERE `namalengkap` LIKE '%%' ESCAPE '!'
OR  `email` LIKE '%%' ESCAPE '!'
OR  `namauser` LIKE '%%' ESCAPE '!'
OR  `an_name` LIKE '%%' ESCAPE '!'
ORDER BY `modified` DESC
 LIMIT 10
ERROR - 2020-02-16 06:57:43 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2020-02-16 06:58:00 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2020-02-16 06:58:36 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2020-02-16 06:59:19 --> Query error: Unknown column 'an_name' in 'where clause' - Invalid query: SELECT *
FROM `logis_users`
WHERE `namalengkap` LIKE '%%' ESCAPE '!'
OR  `email` LIKE '%%' ESCAPE '!'
OR  `namauser` LIKE '%%' ESCAPE '!'
OR  `an_name` LIKE '%%' ESCAPE '!'
ORDER BY `modified` DESC
 LIMIT 10
ERROR - 2020-02-16 07:00:24 --> Query error: Unknown column 'an_name' in 'where clause' - Invalid query: SELECT *
FROM `logis_users`
WHERE `namalengkap` LIKE '%%' ESCAPE '!'
OR  `email` LIKE '%%' ESCAPE '!'
OR  `namauser` LIKE '%%' ESCAPE '!'
OR  `an_name` LIKE '%%' ESCAPE '!'
ORDER BY `modified` DESC
 LIMIT 10
ERROR - 2020-02-16 07:00:45 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2020-02-16 07:00:52 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2020-02-16 07:02:54 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2020-02-16 07:02:57 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2020-02-16 07:03:28 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2020-02-16 07:13:03 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2020-02-16 07:13:24 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2020-02-16 07:24:07 --> Query error: No tables used - Invalid query: SELECT *
 LIMIT 10
ERROR - 2020-02-16 07:26:53 --> Query error: Unknown column 'b.an_name' in 'where clause' - Invalid query: SELECT `namalengkap`, `email`, `namauser`
FROM `logis_users`
WHERE `namalengkap` LIKE '%%' ESCAPE '!'
OR  `email` LIKE '%%' ESCAPE '!'
OR  `namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `modified` DESC
ERROR - 2020-02-16 07:27:32 --> Query error: Unknown column 'an_name' in 'where clause' - Invalid query: SELECT `namalengkap`, `email`, `namauser`
FROM `logis_users`
WHERE `namalengkap` LIKE '%%' ESCAPE '!'
OR  `email` LIKE '%%' ESCAPE '!'
OR  `namauser` LIKE '%%' ESCAPE '!'
OR  `an_name` LIKE '%%' ESCAPE '!'
ORDER BY `modified` DESC
ERROR - 2020-02-16 07:28:29 --> Query error: Unknown column 'logis_usersnamalengkap' in 'where clause' - Invalid query: SELECT `namalengkap`, `email`, `namauser`
FROM `logis_users`
LEFT JOIN `t_acs_nm` as `b` ON `logis_users`.`iduserlevel` = `b`.`id`
WHERE `logis_usersnamalengkap` LIKE '%%' ESCAPE '!'
OR  `logis_usersemail` LIKE '%%' ESCAPE '!'
OR  `logis_usersnamauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `modified` DESC
 LIMIT 10
ERROR - 2020-02-16 07:29:06 --> Query error: Unknown column 'b.an_name' in 'where clause' - Invalid query: SELECT `namalengkap`, `email`, `namauser`
FROM `logis_users`
WHERE `logis_users`.`namalengkap` LIKE '%%' ESCAPE '!'
OR  `logis_users`.`email` LIKE '%%' ESCAPE '!'
OR  `logis_users`.`namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `modified` DESC
ERROR - 2020-02-16 07:30:39 --> Query error: Unknown column 'b.an_name' in 'where clause' - Invalid query: SELECT `namalengkap`, `email`, `namauser`
FROM `logis_users`
WHERE `logis_users`.`namalengkap` LIKE '%%' ESCAPE '!'
OR  `logis_users`.`email` LIKE '%%' ESCAPE '!'
OR  `logis_users`.`namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `modified` DESC
ERROR - 2020-02-16 07:32:20 --> Query error: Unknown column 'b.an_name' in 'where clause' - Invalid query: SELECT *
FROM `logis_users`
WHERE `logis_users`.`namalengkap` LIKE '%%' ESCAPE '!'
OR  `logis_users`.`email` LIKE '%%' ESCAPE '!'
OR  `logis_users`.`namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `modified` DESC
ERROR - 2020-02-16 07:33:21 --> Query error: Unknown column 'b.an_name' in 'where clause' - Invalid query: SELECT *
FROM `logis_users`
WHERE `logis_users`.`namalengkap` LIKE '%%' ESCAPE '!'
OR  `logis_users`.`email` LIKE '%%' ESCAPE '!'
OR  `logis_users`.`namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `modified` DESC
ERROR - 2020-02-16 07:54:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LEFT JOIN `t_acs_nm` as `b` ON `logis_users`.`iduserlevel` = `b`.`id`
WHERE `log' at line 2 - Invalid query: SELECT *
LEFT JOIN `t_acs_nm` as `b` ON `logis_users`.`iduserlevel` = `b`.`id`
WHERE `logis_users`.`namalengkap` LIKE '%%' ESCAPE '!'
OR  `logis_users`.`email` LIKE '%%' ESCAPE '!'
OR  `logis_users`.`namauser` LIKE '%%' ESCAPE '!'
OR  `b`.`an_name` LIKE '%%' ESCAPE '!'
ORDER BY `modified` DESC
 LIMIT 10
ERROR - 2020-02-16 19:08:07 --> Severity: error --> Exception: Call to a member function segment() on null D:\webserver@raka\htdocs\rekam_medis\application\views\backoffice\_layout_main.php 95
